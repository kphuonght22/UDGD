﻿namespace BAKERY_MANAGER
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dGVCustomer = new System.Windows.Forms.DataGridView();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbKHSearch = new System.Windows.Forms.TextBox();
            this.tbSaerchCustomer = new System.Windows.Forms.Button();
            this.cbClassifyCustomer = new System.Windows.Forms.ComboBox();
            this.btAllCustomer = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.tbKHID = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tbKHDisplayName = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.tbKHNumberPhone = new System.Windows.Forms.TextBox();
            this.tbKHPoint = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.btCustomerFix = new System.Windows.Forms.Button();
            this.btCustomerRemove = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dGVCustomer)).BeginInit();
            this.SuspendLayout();
            // 
            // dGVCustomer
            // 
            this.dGVCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9});
            this.dGVCustomer.Location = new System.Drawing.Point(2, 1);
            this.dGVCustomer.Name = "dGVCustomer";
            this.dGVCustomer.ReadOnly = true;
            this.dGVCustomer.Size = new System.Drawing.Size(429, 367);
            this.dGVCustomer.TabIndex = 2;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "ID";
            this.Column6.HeaderText = "ID";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 40;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "Tên khách hàng";
            this.Column7.HeaderText = "Tên khách hàng";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 140;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "Số điện thoại";
            this.Column8.HeaderText = "Số điện thoại";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 110;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "Điểm tích lũy";
            this.Column9.HeaderText = "Điểm tích lũy";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 95;
            // 
            // tbKHSearch
            // 
            this.tbKHSearch.Location = new System.Drawing.Point(524, 15);
            this.tbKHSearch.Name = "tbKHSearch";
            this.tbKHSearch.Size = new System.Drawing.Size(166, 20);
            this.tbKHSearch.TabIndex = 8;
            // 
            // tbSaerchCustomer
            // 
            this.tbSaerchCustomer.Location = new System.Drawing.Point(437, 12);
            this.tbSaerchCustomer.Name = "tbSaerchCustomer";
            this.tbSaerchCustomer.Size = new System.Drawing.Size(81, 25);
            this.tbSaerchCustomer.TabIndex = 9;
            this.tbSaerchCustomer.Text = "Tìm kiếm";
            this.tbSaerchCustomer.UseVisualStyleBackColor = true;
            this.tbSaerchCustomer.Click += new System.EventHandler(this.tbSaerchCustomer_Click);
            // 
            // cbClassifyCustomer
            // 
            this.cbClassifyCustomer.FormattingEnabled = true;
            this.cbClassifyCustomer.Items.AddRange(new object[] {
            "Tất cả",
            "Khách hàng VIP",
            "Khách hàng thông thường",
            "Khách hàng tiềm năng",
            "Khách hàng thường xuyên",
            "Khách hàng không thường xuyên"});
            this.cbClassifyCustomer.Location = new System.Drawing.Point(524, 64);
            this.cbClassifyCustomer.Name = "cbClassifyCustomer";
            this.cbClassifyCustomer.Size = new System.Drawing.Size(166, 21);
            this.cbClassifyCustomer.TabIndex = 39;
            // 
            // btAllCustomer
            // 
            this.btAllCustomer.Location = new System.Drawing.Point(440, 61);
            this.btAllCustomer.Name = "btAllCustomer";
            this.btAllCustomer.Size = new System.Drawing.Size(81, 25);
            this.btAllCustomer.TabIndex = 40;
            this.btAllCustomer.Text = "Khách hàng";
            this.btAllCustomer.UseVisualStyleBackColor = true;
            this.btAllCustomer.Click += new System.EventHandler(this.btAllCustomer_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(437, 117);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(27, 16);
            this.label22.TabIndex = 41;
            this.label22.Text = "ID:";
            // 
            // tbKHID
            // 
            this.tbKHID.Location = new System.Drawing.Point(513, 116);
            this.tbKHID.Name = "tbKHID";
            this.tbKHID.ReadOnly = true;
            this.tbKHID.Size = new System.Drawing.Size(166, 20);
            this.tbKHID.TabIndex = 42;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(434, 166);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(39, 16);
            this.label23.TabIndex = 43;
            this.label23.Text = "Tên:";
            // 
            // tbKHDisplayName
            // 
            this.tbKHDisplayName.Location = new System.Drawing.Point(513, 165);
            this.tbKHDisplayName.Name = "tbKHDisplayName";
            this.tbKHDisplayName.Size = new System.Drawing.Size(166, 20);
            this.tbKHDisplayName.TabIndex = 44;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(434, 221);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(43, 16);
            this.label24.TabIndex = 45;
            this.label24.Text = "SDT:";
            // 
            // tbKHNumberPhone
            // 
            this.tbKHNumberPhone.Location = new System.Drawing.Point(513, 220);
            this.tbKHNumberPhone.Name = "tbKHNumberPhone";
            this.tbKHNumberPhone.Size = new System.Drawing.Size(166, 20);
            this.tbKHNumberPhone.TabIndex = 46;
            // 
            // tbKHPoint
            // 
            this.tbKHPoint.Location = new System.Drawing.Point(513, 271);
            this.tbKHPoint.Name = "tbKHPoint";
            this.tbKHPoint.Size = new System.Drawing.Size(166, 20);
            this.tbKHPoint.TabIndex = 47;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(434, 272);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(47, 16);
            this.label26.TabIndex = 48;
            this.label26.Text = "Điểm:";
            // 
            // btCustomerFix
            // 
            this.btCustomerFix.Location = new System.Drawing.Point(459, 332);
            this.btCustomerFix.Name = "btCustomerFix";
            this.btCustomerFix.Size = new System.Drawing.Size(81, 25);
            this.btCustomerFix.TabIndex = 49;
            this.btCustomerFix.Text = "Sửa";
            this.btCustomerFix.UseVisualStyleBackColor = true;
            this.btCustomerFix.Click += new System.EventHandler(this.btCustomerFix_Click);
            // 
            // btCustomerRemove
            // 
            this.btCustomerRemove.Location = new System.Drawing.Point(598, 332);
            this.btCustomerRemove.Name = "btCustomerRemove";
            this.btCustomerRemove.Size = new System.Drawing.Size(81, 25);
            this.btCustomerRemove.TabIndex = 50;
            this.btCustomerRemove.Text = "Xóa";
            this.btCustomerRemove.UseVisualStyleBackColor = true;
            this.btCustomerRemove.Click += new System.EventHandler(this.btCustomerRemove_Click);
            // 
            // Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(691, 369);
            this.Controls.Add(this.btCustomerRemove);
            this.Controls.Add(this.btCustomerFix);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.tbKHPoint);
            this.Controls.Add(this.tbKHNumberPhone);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.tbKHDisplayName);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.tbKHID);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.btAllCustomer);
            this.Controls.Add(this.cbClassifyCustomer);
            this.Controls.Add(this.tbSaerchCustomer);
            this.Controls.Add(this.tbKHSearch);
            this.Controls.Add(this.dGVCustomer);
            this.Name = "Customer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer";
            ((System.ComponentModel.ISupportInitialize)(this.dGVCustomer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dGVCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.TextBox tbKHSearch;
        private System.Windows.Forms.Button tbSaerchCustomer;
        private System.Windows.Forms.ComboBox cbClassifyCustomer;
        private System.Windows.Forms.Button btAllCustomer;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tbKHID;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tbKHDisplayName;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tbKHNumberPhone;
        private System.Windows.Forms.TextBox tbKHPoint;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btCustomerFix;
        private System.Windows.Forms.Button btCustomerRemove;
    }
}