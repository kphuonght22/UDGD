namespace BAKERY_MANAGER.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("AccountInfo")]
    public partial class AccountInfo
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(50)]
        public string userName { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(100)]
        public string displayName { get; set; }

        [StringLength(100)]
        public string address { get; set; }

        [StringLength(50)]
        public string phone { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int salary { get; set; }

        public virtual Account Account { get; set; }
    }
}
