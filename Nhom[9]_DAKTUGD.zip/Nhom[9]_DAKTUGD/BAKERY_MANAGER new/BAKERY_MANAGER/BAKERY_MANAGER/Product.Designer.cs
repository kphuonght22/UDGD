﻿namespace BAKERY_MANAGER
{
    partial class Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dGVProduct = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label20 = new System.Windows.Forms.Label();
            this.tbSPID = new System.Windows.Forms.TextBox();
            this.tbSPNameFood = new System.Windows.Forms.TextBox();
            this.cbProductClassify = new System.Windows.Forms.ComboBox();
            this.foodCategoryBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.bAKERYDataSet2 = new BAKERY_MANAGER.BAKERYDataSet2();
            this.foodCategoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bAKERYDataSet = new BAKERY_MANAGER.BAKERYDataSet();
            this.tbSPPrice = new System.Windows.Forms.TextBox();
            this.tbProductDescribe = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btProductRemove = new System.Windows.Forms.Button();
            this.btProductFix = new System.Windows.Forms.Button();
            this.foodCategoryTableAdapter = new BAKERY_MANAGER.BAKERYDataSetTableAdapters.FoodCategoryTableAdapter();
            this.tbProductSearch = new System.Windows.Forms.TextBox();
            this.btProductSearch = new System.Windows.Forms.Button();
            this.foodCategoryTableAdapter1 = new BAKERY_MANAGER.BAKERYDataSet2TableAdapters.FoodCategoryTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dGVProduct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodCategoryBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bAKERYDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodCategoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bAKERYDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dGVProduct
            // 
            this.dGVProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVProduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column1});
            this.dGVProduct.Location = new System.Drawing.Point(1, 2);
            this.dGVProduct.Name = "dGVProduct";
            this.dGVProduct.ReadOnly = true;
            this.dGVProduct.Size = new System.Drawing.Size(440, 377);
            this.dGVProduct.TabIndex = 1;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "ID";
            this.Column2.HeaderText = "ID";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 40;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Tên món";
            this.Column3.HeaderText = "Tên món";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 140;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "Loại";
            this.Column4.HeaderText = "Loại";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 110;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "Giá bán";
            this.Column5.HeaderText = "Giá bán";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 105;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Mô tả";
            this.Column1.HeaderText = "Mô tả";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(466, 106);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(72, 16);
            this.label20.TabIndex = 22;
            this.label20.Text = "Tên món:";
            // 
            // tbSPID
            // 
            this.tbSPID.Location = new System.Drawing.Point(544, 56);
            this.tbSPID.Name = "tbSPID";
            this.tbSPID.ReadOnly = true;
            this.tbSPID.Size = new System.Drawing.Size(165, 20);
            this.tbSPID.TabIndex = 23;
            // 
            // tbSPNameFood
            // 
            this.tbSPNameFood.Location = new System.Drawing.Point(544, 105);
            this.tbSPNameFood.Name = "tbSPNameFood";
            this.tbSPNameFood.Size = new System.Drawing.Size(165, 20);
            this.tbSPNameFood.TabIndex = 24;
            // 
            // cbProductClassify
            // 
            this.cbProductClassify.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.foodCategoryBindingSource1, "name", true));
            this.cbProductClassify.DataSource = this.foodCategoryBindingSource1;
            this.cbProductClassify.DisplayMember = "name";
            this.cbProductClassify.FormattingEnabled = true;
            this.cbProductClassify.Location = new System.Drawing.Point(544, 149);
            this.cbProductClassify.Name = "cbProductClassify";
            this.cbProductClassify.Size = new System.Drawing.Size(165, 21);
            this.cbProductClassify.TabIndex = 25;
            this.cbProductClassify.ValueMember = "name";
            // 
            // foodCategoryBindingSource1
            // 
            this.foodCategoryBindingSource1.DataMember = "FoodCategory";
            this.foodCategoryBindingSource1.DataSource = this.bAKERYDataSet2;
            // 
            // bAKERYDataSet2
            // 
            this.bAKERYDataSet2.DataSetName = "BAKERYDataSet2";
            this.bAKERYDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // foodCategoryBindingSource
            // 
            this.foodCategoryBindingSource.DataMember = "FoodCategory";
            this.foodCategoryBindingSource.DataSource = this.bAKERYDataSet;
            // 
            // bAKERYDataSet
            // 
            this.bAKERYDataSet.DataSetName = "BAKERYDataSet";
            this.bAKERYDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbSPPrice
            // 
            this.tbSPPrice.Location = new System.Drawing.Point(544, 192);
            this.tbSPPrice.Multiline = true;
            this.tbSPPrice.Name = "tbSPPrice";
            this.tbSPPrice.Size = new System.Drawing.Size(165, 21);
            this.tbSPPrice.TabIndex = 26;
            // 
            // tbProductDescribe
            // 
            this.tbProductDescribe.Location = new System.Drawing.Point(544, 237);
            this.tbProductDescribe.Multiline = true;
            this.tbProductDescribe.Name = "tbProductDescribe";
            this.tbProductDescribe.Size = new System.Drawing.Size(165, 76);
            this.tbProductDescribe.TabIndex = 27;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(466, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 16);
            this.label3.TabIndex = 28;
            this.label3.Text = "ID:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(466, 149);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(42, 16);
            this.label17.TabIndex = 29;
            this.label17.Text = "Loại:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(466, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 16);
            this.label5.TabIndex = 30;
            this.label5.Text = "Giá:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(466, 271);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 16);
            this.label19.TabIndex = 31;
            this.label19.Text = "Mô tải:";
            // 
            // btProductRemove
            // 
            this.btProductRemove.Location = new System.Drawing.Point(621, 343);
            this.btProductRemove.Name = "btProductRemove";
            this.btProductRemove.Size = new System.Drawing.Size(88, 26);
            this.btProductRemove.TabIndex = 32;
            this.btProductRemove.Text = "Xóa";
            this.btProductRemove.UseVisualStyleBackColor = true;
            this.btProductRemove.Click += new System.EventHandler(this.btProductRemove_Click);
            // 
            // btProductFix
            // 
            this.btProductFix.Location = new System.Drawing.Point(499, 343);
            this.btProductFix.Name = "btProductFix";
            this.btProductFix.Size = new System.Drawing.Size(88, 26);
            this.btProductFix.TabIndex = 33;
            this.btProductFix.Text = "Sửa";
            this.btProductFix.UseVisualStyleBackColor = true;
            this.btProductFix.Click += new System.EventHandler(this.btProductFix_Click);
            // 
            // foodCategoryTableAdapter
            // 
            this.foodCategoryTableAdapter.ClearBeforeFill = true;
            // 
            // tbProductSearch
            // 
            this.tbProductSearch.Location = new System.Drawing.Point(544, 12);
            this.tbProductSearch.Name = "tbProductSearch";
            this.tbProductSearch.Size = new System.Drawing.Size(165, 20);
            this.tbProductSearch.TabIndex = 34;
            // 
            // btProductSearch
            // 
            this.btProductSearch.Location = new System.Drawing.Point(447, 9);
            this.btProductSearch.Name = "btProductSearch";
            this.btProductSearch.Size = new System.Drawing.Size(88, 24);
            this.btProductSearch.TabIndex = 35;
            this.btProductSearch.Text = "Tìm kiếm";
            this.btProductSearch.UseVisualStyleBackColor = true;
            this.btProductSearch.Click += new System.EventHandler(this.btProductSearch_Click);
            // 
            // foodCategoryTableAdapter1
            // 
            this.foodCategoryTableAdapter1.ClearBeforeFill = true;
            // 
            // Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(721, 381);
            this.Controls.Add(this.btProductSearch);
            this.Controls.Add(this.tbProductSearch);
            this.Controls.Add(this.btProductFix);
            this.Controls.Add(this.btProductRemove);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbProductDescribe);
            this.Controls.Add(this.tbSPPrice);
            this.Controls.Add(this.cbProductClassify);
            this.Controls.Add(this.tbSPNameFood);
            this.Controls.Add(this.tbSPID);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.dGVProduct);
            this.Name = "Product";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product";
            this.Load += new System.EventHandler(this.Product_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dGVProduct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodCategoryBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bAKERYDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodCategoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bAKERYDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dGVProduct;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbSPID;
        private System.Windows.Forms.TextBox tbSPNameFood;
        private System.Windows.Forms.ComboBox cbProductClassify;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.TextBox tbSPPrice;
        private System.Windows.Forms.TextBox tbProductDescribe;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btProductRemove;
        private System.Windows.Forms.Button btProductFix;
        private BAKERYDataSet bAKERYDataSet;
        private System.Windows.Forms.BindingSource foodCategoryBindingSource;
        private BAKERYDataSetTableAdapters.FoodCategoryTableAdapter foodCategoryTableAdapter;
        private System.Windows.Forms.TextBox tbProductSearch;
        private System.Windows.Forms.Button btProductSearch;
        private BAKERYDataSet2 bAKERYDataSet2;
        private System.Windows.Forms.BindingSource foodCategoryBindingSource1;
        private BAKERYDataSet2TableAdapters.FoodCategoryTableAdapter foodCategoryTableAdapter1;
    }
}