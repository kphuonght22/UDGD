﻿using BAKERY_MANAGER.Function;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAKERY_MANAGER
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
            DataCustomer();
            detailCustomer();
        }
        void detailCustomer()
        {
            tbKHID.DataBindings.Clear();
            tbKHDisplayName.DataBindings.Clear();
            tbKHNumberPhone.DataBindings.Clear();
            tbKHPoint.DataBindings.Clear();

            tbKHID.DataBindings.Add(new Binding("Text", dGVCustomer.DataSource, "ID", true, DataSourceUpdateMode.Never));
            tbKHDisplayName.DataBindings.Add(new Binding("Text", dGVCustomer.DataSource, "Tên khách hàng", true, DataSourceUpdateMode.Never));
            tbKHNumberPhone.DataBindings.Add(new Binding("Text", dGVCustomer.DataSource, "Số điện thoại", true, DataSourceUpdateMode.Never));
            tbKHPoint.DataBindings.Add(new Binding("Text", dGVCustomer.DataSource, "Điểm tích lũy", true, DataSourceUpdateMode.Never));
        }
        void CustomerNull()
        {
            tbKHID.Text = "";
            tbKHDisplayName.Text = "";
            tbKHNumberPhone.Text = "";
            tbKHPoint.Text = "";
        }
        public void DataCustomer()
        {
            string query = "select Customer.id as N'ID',name as N'Tên khách hàng'," +
                " phone as N'Số điện thoại', Point as N'Điểm tích lũy' from Customer";
            queryData dataCustomer = new queryData();
            dGVCustomer.DataSource = dataCustomer.dataTable(query);
        }

        private void tbSaerchCustomer_Click(object sender, EventArgs e)
        {
            string name = tbKHSearch.Text;
            string query = "select Customer.id as N'ID',name as N'Tên khách hàng'," +
                " phone as N'Số điện thoại', Point as N'Điểm tích lũy' from Customer" +
                " where name like N'%" + name + "%'";
            queryData dataCustomer = new queryData();
            dGVCustomer.DataSource = dataCustomer.dataTable(query);
            if (dGVCustomer.Rows.Count > 1)
            {
                detailCustomer();
                MessageBox.Show("Tìm kiếm thành công!");
            }
            else
            {
                CustomerNull();
                MessageBox.Show("Không tìm thấy khách hành có tên: " + name);
            }
        }

        private void btAllCustomer_Click(object sender, EventArgs e)
        {
            string key = cbClassifyCustomer.Text;
            string query;
            queryData data = new queryData();
            if (key == ""||key == "Tất cả")
            {
                query = "select Customer.id as N'ID',name as N'Tên khách hàng'," +
                " phone as N'Số điện thoại', Point as N'Điểm tích lũy' from Customer";
                dGVCustomer.DataSource = data.dataTable(query);
            }
            else if (key == "Khách hàng VIP")
            {
                query = string.Format("select Customer.id as N'ID', name as N'Tên khách hàng'," +
                "phone as N'Số điện thoại',point as N'Điểm tích lũy' " +
                "from Customer where point > 2000");
                dGVCustomer.DataSource = data.dataTable(query);
            }
            else if (key == "Khách hàng tiềm năng")
            {
                query = "select Customer.id as N'ID', name as N'Tên khách hàng',phone as N'Số điện thoại',point as N'Điểm tích lũy' from Customer, Bill " +
                    "where Customer.id = Bill.idCustomer " +
                    "group by Customer.name,Customer.id,phone,point having SUM(moneyPay) > 5000000";
                dGVCustomer.DataSource = data.dataTable(query);
            }
            else if (key == "Khách hàng thường xuyên")
            {
                int month = DateTime.Now.Month;
                int year = DateTime.Now.Year;
                if (month < 3)
                {
                    year -= 1;
                    int tmp = Math.Abs(3 - month);
                    month = 12 - tmp;
                }
                else month = month - 3;
                month.ToString(); year.ToString();
                query = "select Customer.id as N'ID', name as N'Tên khách hàng', phone as N'Số điện thoại',point as N'Điểm tích lũy' from Customer, bill where MONTH(timePay) >" + month +
                    "and YEAR(timePay)>=" + year + "  and Bill.idCustomer = Customer.id group by Customer.id,name,phone,point";
                dGVCustomer.DataSource = data.dataTable(query);
            }
            else if (key == "Khách hàng không thường xuyên")
            {
                int month = DateTime.Now.Month;
                int year = DateTime.Now.Year;
                if (month < 3)
                {
                    year -= 1;
                    int tmp = Math.Abs(3 - month);
                    month = 12 - tmp;
                }
                else month = month - 3;
                month.ToString(); year.ToString();
                query = "select Customer.id as N'ID', name as N'Tên khách hàng', phone as N'Số điện thoại',point as N'Điểm tích lũy' from Customer, bill where MONTH(timePay) <" + month +
                    "and YEAR(timePay)<=" + year + "  and Bill.idCustomer = Customer.id group by Customer.id,name,phone,point";
                dGVCustomer.DataSource = data.dataTable(query);
            }
            else
            {
                query = "select Customer.id as N'ID', name as N'Tên khách hàng'," +
                "phone as N'Số điện thoại', point as N'Điểm tích lũy' " +
                "from Customer where point < 2000";
                dGVCustomer.DataSource = data.dataTable(query);
            }
            //
            if (dGVCustomer.Rows.Count > 1)
            {
                detailCustomer();
            }
            else
            {
                CustomerNull();
                MessageBox.Show("Không tìm thấy!");
            }
        }

        private void btCustomerFix_Click(object sender, EventArgs e)
        {
            int id = int.Parse(tbKHID.Text);
            string name = tbKHDisplayName.Text;
            int phone = int.Parse(tbKHNumberPhone.Text);
            int point = int.Parse(tbKHPoint.Text);
            string query = string.Format("update Customer set phone={0},name=N'{1}',point={2} where id={3}",
                phone.ToString(), name, point.ToString(), id.ToString());
            queryData data = new queryData();
            data.AddOrFixOrDelete(query);
            MessageBox.Show("Sửa thông tin thành công khách hàng : " + name);
            DataCustomer();
            detailCustomer();
        }

        private void btCustomerRemove_Click(object sender, EventArgs e)
        {
            string ID = tbKHID.Text;
            string Name = tbKHDisplayName.Text;
            string delete = string.Format("delete from Bill where idCustomer = {0}", ID);
            string delete1 = string.Format("delete from Customer where id = {0}", ID);
            queryData data = new queryData();
            queryData data1 = new queryData();
            data.AddOrFixOrDelete(delete);
            data1.AddOrFixOrDelete(delete1);
            MessageBox.Show("Đã xóa khách hàng " + Name + " thành công!");
            DataCustomer();
            detailCustomer();
        }
    }
}
