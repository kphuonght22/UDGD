﻿using BAKERY_MANAGER.Function;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAKERY_MANAGER
{
    public partial class ChangePassAdmin : Form
    {
        public ChangePassAdmin()
        {
            InitializeComponent();
            userName();
        }
        void userName()
        {
            tbChangPassUserName.Text = "admin";
        }
        private void btOKChangePassad_Click(object sender, EventArgs e)
        {
            string pass = tbChangePass1.Text;
            string pass1 = tbChangePass2.Text;
            string userName = tbChangPassUserName.Text;
            if (pass != pass1)
            {
                MessageBox.Show("Xác nhận mật khẩu không chính xác!");
            }
            else
            {
                string query = string.Format("update Account set passWord=N'{0}',type=1 where userName=N'{1}'", pass, userName);
                queryData data = new queryData();
                data.AddOrFixOrDelete(query);
                MessageBox.Show("Đổi mật khẩu thành công!");
            }
        }

        private void btCancelChangePassad_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
