﻿namespace BakeryManeger
{
    partial class fStaffManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.thôngTinCáNhânToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemAccountInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.itemChangePass = new System.Windows.Forms.ToolStripMenuItem();
            this.itemExit = new System.Windows.Forms.ToolStripMenuItem();
            this.itemAddAccount = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSearchFood = new System.Windows.Forms.Button();
            this.tbxSearchFood = new System.Windows.Forms.TextBox();
            this.cbxFoodCategory = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnAddFood = new System.Windows.Forms.Button();
            this.amount = new System.Windows.Forms.NumericUpDown();
            this.lsvFood = new System.Windows.Forms.ListView();
            this.clSTT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbxPoint = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnCheck = new System.Windows.Forms.Button();
            this.tbxCheckPhone = new System.Windows.Forms.TextBox();
            this.cbxCustomer = new System.Windows.Forms.CheckBox();
            this.tbxIdBill = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbxStaffName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbxTime = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbxThanhTien = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.numSale = new System.Windows.Forms.NumericUpDown();
            this.btnClearBill = new System.Windows.Forms.Button();
            this.btnPay = new System.Windows.Forms.Button();
            this.lvsBill = new System.Windows.Forms.ListView();
            this.clFoodName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clDonGia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clCount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clbPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.amount)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSale)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinCáNhânToolStripMenuItem,
            this.itemAddAccount});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(916, 28);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // thôngTinCáNhânToolStripMenuItem
            // 
            this.thôngTinCáNhânToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itemAccountInfo,
            this.itemChangePass,
            this.itemExit});
            this.thôngTinCáNhânToolStripMenuItem.Name = "thôngTinCáNhânToolStripMenuItem";
            this.thôngTinCáNhânToolStripMenuItem.Size = new System.Drawing.Size(151, 24);
            this.thôngTinCáNhânToolStripMenuItem.Text = "Thông tin tài khoản";
            // 
            // itemAccountInfo
            // 
            this.itemAccountInfo.Name = "itemAccountInfo";
            this.itemAccountInfo.Size = new System.Drawing.Size(210, 26);
            this.itemAccountInfo.Text = "Thông tin cá nhân";
            this.itemAccountInfo.Click += new System.EventHandler(this.itemAccountInfo_Click);
            // 
            // itemChangePass
            // 
            this.itemChangePass.Name = "itemChangePass";
            this.itemChangePass.Size = new System.Drawing.Size(210, 26);
            this.itemChangePass.Text = "Đổi mật khẩu";
            this.itemChangePass.Click += new System.EventHandler(this.itemChangePass_Click);
            // 
            // itemExit
            // 
            this.itemExit.Name = "itemExit";
            this.itemExit.Size = new System.Drawing.Size(210, 26);
            this.itemExit.Text = "Đăng xuất";
            this.itemExit.Click += new System.EventHandler(this.itemExit_Click);
            // 
            // itemAddAccount
            // 
            this.itemAddAccount.Name = "itemAddAccount";
            this.itemAddAccount.Size = new System.Drawing.Size(146, 24);
            this.itemAddAccount.Text = "Đăng kí thành viên";
            this.itemAddAccount.Click += new System.EventHandler(this.itemAddAccount_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(15, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(888, 50);
            this.label1.TabIndex = 6;
            this.label1.Text = "TRUNG THỰC - NHIỆT TÌNH - VUI VẺ - SÁNG TẠO";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnSearchFood);
            this.panel1.Controls.Add(this.tbxSearchFood);
            this.panel1.Controls.Add(this.cbxFoodCategory);
            this.panel1.Location = new System.Drawing.Point(15, 82);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(340, 74);
            this.panel1.TabIndex = 7;
            // 
            // btnSearchFood
            // 
            this.btnSearchFood.Location = new System.Drawing.Point(252, 33);
            this.btnSearchFood.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSearchFood.Name = "btnSearchFood";
            this.btnSearchFood.Size = new System.Drawing.Size(85, 39);
            this.btnSearchFood.TabIndex = 2;
            this.btnSearchFood.Text = "Tìm kiếm";
            this.btnSearchFood.UseVisualStyleBackColor = true;
            this.btnSearchFood.Click += new System.EventHandler(this.btnSearchFood_Click);
            // 
            // tbxSearchFood
            // 
            this.tbxSearchFood.Location = new System.Drawing.Point(3, 41);
            this.tbxSearchFood.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxSearchFood.Name = "tbxSearchFood";
            this.tbxSearchFood.Size = new System.Drawing.Size(243, 22);
            this.tbxSearchFood.TabIndex = 1;
            // 
            // cbxFoodCategory
            // 
            this.cbxFoodCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxFoodCategory.FormattingEnabled = true;
            this.cbxFoodCategory.Location = new System.Drawing.Point(3, 2);
            this.cbxFoodCategory.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbxFoodCategory.Name = "cbxFoodCategory";
            this.cbxFoodCategory.Size = new System.Drawing.Size(335, 24);
            this.cbxFoodCategory.TabIndex = 0;
            this.cbxFoodCategory.SelectedIndexChanged += new System.EventHandler(this.cbxFoodCategory_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnAddFood);
            this.panel2.Controls.Add(this.amount);
            this.panel2.Controls.Add(this.lsvFood);
            this.panel2.Location = new System.Drawing.Point(15, 180);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(340, 539);
            this.panel2.TabIndex = 8;
            // 
            // btnAddFood
            // 
            this.btnAddFood.Location = new System.Drawing.Point(217, 486);
            this.btnAddFood.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddFood.Name = "btnAddFood";
            this.btnAddFood.Size = new System.Drawing.Size(120, 50);
            this.btnAddFood.TabIndex = 2;
            this.btnAddFood.Text = "Thêm";
            this.btnAddFood.UseVisualStyleBackColor = true;
            this.btnAddFood.Click += new System.EventHandler(this.btnAddFood_Click);
            // 
            // amount
            // 
            this.amount.Location = new System.Drawing.Point(217, 457);
            this.amount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(120, 22);
            this.amount.TabIndex = 1;
            this.amount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lsvFood
            // 
            this.lsvFood.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clSTT,
            this.clName,
            this.clPrice});
            this.lsvFood.FullRowSelect = true;
            this.lsvFood.HideSelection = false;
            this.lsvFood.Location = new System.Drawing.Point(3, 2);
            this.lsvFood.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lsvFood.Name = "lsvFood";
            this.lsvFood.Size = new System.Drawing.Size(337, 448);
            this.lsvFood.TabIndex = 0;
            this.lsvFood.UseCompatibleStateImageBehavior = false;
            this.lsvFood.View = System.Windows.Forms.View.Details;
            // 
            // clSTT
            // 
            this.clSTT.Text = "STT";
            this.clSTT.Width = 50;
            // 
            // clName
            // 
            this.clName.Text = "Tên";
            this.clName.Width = 123;
            // 
            // clPrice
            // 
            this.clPrice.Text = "Giá";
            this.clPrice.Width = 100;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tbxPoint);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.btnCheck);
            this.panel3.Controls.Add(this.tbxCheckPhone);
            this.panel3.Controls.Add(this.cbxCustomer);
            this.panel3.Controls.Add(this.tbxIdBill);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.tbxStaffName);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.tbxTime);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.tbxThanhTien);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.numSale);
            this.panel3.Controls.Add(this.btnClearBill);
            this.panel3.Controls.Add(this.btnPay);
            this.panel3.Controls.Add(this.lvsBill);
            this.panel3.Location = new System.Drawing.Point(425, 85);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(477, 634);
            this.panel3.TabIndex = 9;
            // 
            // tbxPoint
            // 
            this.tbxPoint.Location = new System.Drawing.Point(129, 607);
            this.tbxPoint.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxPoint.Name = "tbxPoint";
            this.tbxPoint.ReadOnly = true;
            this.tbxPoint.Size = new System.Drawing.Size(100, 22);
            this.tbxPoint.TabIndex = 19;
            this.tbxPoint.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(129, 581);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 23);
            this.label6.TabIndex = 18;
            this.label6.Text = "Tích lũy";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCheck
            // 
            this.btnCheck.BackColor = System.Drawing.Color.Gainsboro;
            this.btnCheck.Location = new System.Drawing.Point(393, 62);
            this.btnCheck.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(81, 23);
            this.btnCheck.TabIndex = 17;
            this.btnCheck.Text = "Check";
            this.btnCheck.UseVisualStyleBackColor = false;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // tbxCheckPhone
            // 
            this.tbxCheckPhone.Location = new System.Drawing.Point(199, 62);
            this.tbxCheckPhone.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxCheckPhone.Name = "tbxCheckPhone";
            this.tbxCheckPhone.ReadOnly = true;
            this.tbxCheckPhone.Size = new System.Drawing.Size(188, 22);
            this.tbxCheckPhone.TabIndex = 16;
            this.tbxCheckPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cbxCustomer
            // 
            this.cbxCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cbxCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxCustomer.Location = new System.Drawing.Point(3, 62);
            this.cbxCustomer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbxCustomer.Name = "cbxCustomer";
            this.cbxCustomer.Size = new System.Drawing.Size(175, 25);
            this.cbxCustomer.TabIndex = 15;
            this.cbxCustomer.Text = "Thành viên";
            this.cbxCustomer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbxCustomer.UseVisualStyleBackColor = false;
            this.cbxCustomer.CheckedChanged += new System.EventHandler(this.cbxCustomer_CheckedChanged);
            // 
            // tbxIdBill
            // 
            this.tbxIdBill.Location = new System.Drawing.Point(199, 4);
            this.tbxIdBill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxIdBill.Name = "tbxIdBill";
            this.tbxIdBill.ReadOnly = true;
            this.tbxIdBill.Size = new System.Drawing.Size(48, 22);
            this.tbxIdBill.TabIndex = 13;
            this.tbxIdBill.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(4, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(173, 23);
            this.label5.TabIndex = 12;
            this.label5.Text = "Mã đơn hàng";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbxStaffName
            // 
            this.tbxStaffName.Location = new System.Drawing.Point(199, 33);
            this.tbxStaffName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxStaffName.Name = "tbxStaffName";
            this.tbxStaffName.ReadOnly = true;
            this.tbxStaffName.Size = new System.Drawing.Size(275, 22);
            this.tbxStaffName.TabIndex = 11;
            this.tbxStaffName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(175, 23);
            this.label4.TabIndex = 10;
            this.label4.Text = "Nhân viên";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbxTime
            // 
            this.tbxTime.Location = new System.Drawing.Point(299, 2);
            this.tbxTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxTime.Name = "tbxTime";
            this.tbxTime.ReadOnly = true;
            this.tbxTime.Size = new System.Drawing.Size(175, 22);
            this.tbxTime.TabIndex = 9;
            this.tbxTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(247, 551);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 23);
            this.label3.TabIndex = 8;
            this.label3.Text = "Thành tiền ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbxThanhTien
            // 
            this.tbxThanhTien.Location = new System.Drawing.Point(355, 553);
            this.tbxThanhTien.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbxThanhTien.Name = "tbxThanhTien";
            this.tbxThanhTien.ReadOnly = true;
            this.tbxThanhTien.Size = new System.Drawing.Size(120, 22);
            this.tbxThanhTien.TabIndex = 7;
            this.tbxThanhTien.Text = "0";
            this.tbxThanhTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(247, 581);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 23);
            this.label2.TabIndex = 6;
            this.label2.Text = "Giảm giá";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numSale
            // 
            this.numSale.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numSale.Location = new System.Drawing.Point(247, 609);
            this.numSale.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.numSale.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numSale.Name = "numSale";
            this.numSale.Size = new System.Drawing.Size(101, 22);
            this.numSale.TabIndex = 5;
            this.numSale.ValueChanged += new System.EventHandler(this.numSale_ValueChanged);
            // 
            // btnClearBill
            // 
            this.btnClearBill.Location = new System.Drawing.Point(3, 581);
            this.btnClearBill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnClearBill.Name = "btnClearBill";
            this.btnClearBill.Size = new System.Drawing.Size(120, 50);
            this.btnClearBill.TabIndex = 4;
            this.btnClearBill.Text = "Hủy đơn";
            this.btnClearBill.UseVisualStyleBackColor = true;
            this.btnClearBill.Click += new System.EventHandler(this.btnClearBill_Click);
            // 
            // btnPay
            // 
            this.btnPay.Location = new System.Drawing.Point(355, 581);
            this.btnPay.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(120, 50);
            this.btnPay.TabIndex = 3;
            this.btnPay.Text = "Thanh toán";
            this.btnPay.UseVisualStyleBackColor = true;
            this.btnPay.Click += new System.EventHandler(this.btnPay_Click);
            // 
            // lvsBill
            // 
            this.lvsBill.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clFoodName,
            this.clDonGia,
            this.clCount,
            this.clbPrice});
            this.lvsBill.FullRowSelect = true;
            this.lvsBill.HideSelection = false;
            this.lvsBill.Location = new System.Drawing.Point(3, 90);
            this.lvsBill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lvsBill.Name = "lvsBill";
            this.lvsBill.Size = new System.Drawing.Size(471, 456);
            this.lvsBill.TabIndex = 0;
            this.lvsBill.UseCompatibleStateImageBehavior = false;
            this.lvsBill.View = System.Windows.Forms.View.Details;
            // 
            // clFoodName
            // 
            this.clFoodName.Text = "Tên";
            this.clFoodName.Width = 100;
            // 
            // clDonGia
            // 
            this.clDonGia.Text = "Đơn giá";
            this.clDonGia.Width = 70;
            // 
            // clCount
            // 
            this.clCount.Text = "Số lượng";
            this.clCount.Width = 80;
            // 
            // clbPrice
            // 
            this.clbPrice.Text = "Giá";
            this.clbPrice.Width = 80;
            // 
            // fStaffManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 727);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "fStaffManager";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phần mềm quản lý tiệm bánh";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.amount)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSale)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem thôngTinCáNhânToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemAccountInfo;
        private System.Windows.Forms.ToolStripMenuItem itemChangePass;
        private System.Windows.Forms.ToolStripMenuItem itemExit;
        private System.Windows.Forms.ToolStripMenuItem itemAddAccount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSearchFood;
        private System.Windows.Forms.TextBox tbxSearchFood;
        private System.Windows.Forms.ComboBox cbxFoodCategory;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnAddFood;
        private System.Windows.Forms.NumericUpDown amount;
        private System.Windows.Forms.ListView lsvFood;
        private System.Windows.Forms.ColumnHeader clSTT;
        private System.Windows.Forms.ColumnHeader clName;
        private System.Windows.Forms.ColumnHeader clPrice;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbxPoint;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.TextBox tbxCheckPhone;
        private System.Windows.Forms.CheckBox cbxCustomer;
        private System.Windows.Forms.TextBox tbxIdBill;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbxStaffName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbxTime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbxThanhTien;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numSale;
        private System.Windows.Forms.Button btnClearBill;
        private System.Windows.Forms.Button btnPay;
        private System.Windows.Forms.ListView lvsBill;
        private System.Windows.Forms.ColumnHeader clFoodName;
        private System.Windows.Forms.ColumnHeader clDonGia;
        private System.Windows.Forms.ColumnHeader clCount;
        private System.Windows.Forms.ColumnHeader clbPrice;
    }
}