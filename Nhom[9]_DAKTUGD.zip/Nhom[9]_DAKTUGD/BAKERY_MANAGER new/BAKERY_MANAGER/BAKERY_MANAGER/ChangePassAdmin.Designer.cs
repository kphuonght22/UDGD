﻿namespace BAKERY_MANAGER
{
    partial class ChangePassAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btCancelChangePassad = new System.Windows.Forms.Button();
            this.btOKChangePassad = new System.Windows.Forms.Button();
            this.tbChangPassUserName = new System.Windows.Forms.TextBox();
            this.tbChangePass1 = new System.Windows.Forms.TextBox();
            this.tbChangePass2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(108, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Đổi mật khẩu";
            // 
            // btCancelChangePassad
            // 
            this.btCancelChangePassad.Location = new System.Drawing.Point(38, 221);
            this.btCancelChangePassad.Name = "btCancelChangePassad";
            this.btCancelChangePassad.Size = new System.Drawing.Size(88, 23);
            this.btCancelChangePassad.TabIndex = 1;
            this.btCancelChangePassad.Text = "Cancel";
            this.btCancelChangePassad.UseVisualStyleBackColor = true;
            this.btCancelChangePassad.Click += new System.EventHandler(this.btCancelChangePassad_Click);
            // 
            // btOKChangePassad
            // 
            this.btOKChangePassad.Location = new System.Drawing.Point(205, 221);
            this.btOKChangePassad.Name = "btOKChangePassad";
            this.btOKChangePassad.Size = new System.Drawing.Size(88, 23);
            this.btOKChangePassad.TabIndex = 2;
            this.btOKChangePassad.Text = "OK";
            this.btOKChangePassad.UseVisualStyleBackColor = true;
            this.btOKChangePassad.Click += new System.EventHandler(this.btOKChangePassad_Click);
            // 
            // tbChangPassUserName
            // 
            this.tbChangPassUserName.Location = new System.Drawing.Point(149, 57);
            this.tbChangPassUserName.Name = "tbChangPassUserName";
            this.tbChangPassUserName.ReadOnly = true;
            this.tbChangPassUserName.Size = new System.Drawing.Size(153, 20);
            this.tbChangPassUserName.TabIndex = 3;
            // 
            // tbChangePass1
            // 
            this.tbChangePass1.Location = new System.Drawing.Point(149, 105);
            this.tbChangePass1.Name = "tbChangePass1";
            this.tbChangePass1.PasswordChar = '*';
            this.tbChangePass1.Size = new System.Drawing.Size(153, 20);
            this.tbChangePass1.TabIndex = 4;
            // 
            // tbChangePass2
            // 
            this.tbChangePass2.Location = new System.Drawing.Point(149, 160);
            this.tbChangePass2.Name = "tbChangePass2";
            this.tbChangePass2.PasswordChar = '*';
            this.tbChangePass2.Size = new System.Drawing.Size(153, 20);
            this.tbChangePass2.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(2, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Tên tài khoảng:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(2, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Mật khẩu:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(2, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Xác nhận mật khẩu:";
            // 
            // ChangePassAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(312, 270);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbChangePass2);
            this.Controls.Add(this.tbChangePass1);
            this.Controls.Add(this.tbChangPassUserName);
            this.Controls.Add(this.btOKChangePassad);
            this.Controls.Add(this.btCancelChangePassad);
            this.Controls.Add(this.label1);
            this.Name = "ChangePassAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đổi mật khẩu Admin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btCancelChangePassad;
        private System.Windows.Forms.Button btOKChangePassad;
        private System.Windows.Forms.TextBox tbChangPassUserName;
        private System.Windows.Forms.TextBox tbChangePass1;
        private System.Windows.Forms.TextBox tbChangePass2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}