﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAKERY_MANAGER.Function
{
    public class queryData
    {
        private string connection = "Data Source=.\\SQLEXPRESS;Initial Catalog=BAKERY;Integrated Security=True";
        //
        public DataTable dataTable(string query)
        {
            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();
            SqlCommand command = new SqlCommand(query, sqlConnection);
            DataTable data = new DataTable();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
            dataAdapter.Fill(data);
            sqlConnection.Close();
            return data;
        }
        public string TextBox(string query)
        {
            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();
            SqlCommand command = new SqlCommand(query, sqlConnection);
            string com = command.ExecuteScalar().ToString();
            sqlConnection.Close();
            return com;
        }

        public void AddOrFixOrDelete(string query)
        {
            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();
            SqlCommand command = new SqlCommand(query, sqlConnection);
            command.ExecuteNonQuery();
        }
    }
}
