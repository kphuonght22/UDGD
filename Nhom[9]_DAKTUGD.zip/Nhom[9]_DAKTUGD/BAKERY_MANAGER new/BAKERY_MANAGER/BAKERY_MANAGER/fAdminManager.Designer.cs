﻿namespace BAKERY_MANAGER
{
    partial class fAdminManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fAdminManager));
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.TKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ngàyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoNgàyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoTuầnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoThàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theoQuýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nămToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tuầnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảMónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmMónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmLoạiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.KHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.NVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảSửaXóaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmNhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.InfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đổiMậtKhẩuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.viewHlepToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dGVRevenue = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sdt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.money = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.point = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbDTRevenue = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVRevenue)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TKToolStripMenuItem,
            this.MToolStripMenuItem,
            this.KHToolStripMenuItem,
            this.NVToolStripMenuItem,
            this.InfoToolStripMenuItem,
            this.ExitToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.DarkMagenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(56, 22);
            this.toolStripDropDownButton1.Text = "Admin";
            // 
            // TKToolStripMenuItem
            // 
            this.TKToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ngàyToolStripMenuItem,
            this.tuầnToolStripMenuItem});
            this.TKToolStripMenuItem.Name = "TKToolStripMenuItem";
            this.TKToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.TKToolStripMenuItem.Text = "Thống kê";
            // 
            // ngàyToolStripMenuItem
            // 
            this.ngàyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.theoNgàyToolStripMenuItem,
            this.theoTuầnToolStripMenuItem,
            this.theoThàngToolStripMenuItem,
            this.theoQuýToolStripMenuItem,
            this.nămToolStripMenuItem});
            this.ngàyToolStripMenuItem.Name = "ngàyToolStripMenuItem";
            this.ngàyToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.ngàyToolStripMenuItem.Text = "Doanh thu";
            // 
            // theoNgàyToolStripMenuItem
            // 
            this.theoNgàyToolStripMenuItem.Name = "theoNgàyToolStripMenuItem";
            this.theoNgàyToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.theoNgàyToolStripMenuItem.Text = "Hôm nay";
            this.theoNgàyToolStripMenuItem.Click += new System.EventHandler(this.theoNgàyToolStripMenuItem_Click);
            // 
            // theoTuầnToolStripMenuItem
            // 
            this.theoTuầnToolStripMenuItem.Name = "theoTuầnToolStripMenuItem";
            this.theoTuầnToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.theoTuầnToolStripMenuItem.Text = "Theo tuần";
            this.theoTuầnToolStripMenuItem.Click += new System.EventHandler(this.theoTuầnToolStripMenuItem_Click);
            // 
            // theoThàngToolStripMenuItem
            // 
            this.theoThàngToolStripMenuItem.Name = "theoThàngToolStripMenuItem";
            this.theoThàngToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.theoThàngToolStripMenuItem.Text = "Theo thàng";
            this.theoThàngToolStripMenuItem.Click += new System.EventHandler(this.theoThàngToolStripMenuItem_Click);
            // 
            // theoQuýToolStripMenuItem
            // 
            this.theoQuýToolStripMenuItem.Name = "theoQuýToolStripMenuItem";
            this.theoQuýToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.theoQuýToolStripMenuItem.Text = "Theo quý";
            this.theoQuýToolStripMenuItem.Click += new System.EventHandler(this.theoQuýToolStripMenuItem_Click);
            // 
            // nămToolStripMenuItem
            // 
            this.nămToolStripMenuItem.Name = "nămToolStripMenuItem";
            this.nămToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.nămToolStripMenuItem.Text = "Năm";
            this.nămToolStripMenuItem.Click += new System.EventHandler(this.nămToolStripMenuItem_Click);
            // 
            // tuầnToolStripMenuItem
            // 
            this.tuầnToolStripMenuItem.Name = "tuầnToolStripMenuItem";
            this.tuầnToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.tuầnToolStripMenuItem.Text = "Món";
            this.tuầnToolStripMenuItem.Click += new System.EventHandler(this.tuầnToolStripMenuItem_Click);
            // 
            // MToolStripMenuItem
            // 
            this.MToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tấtCảMónToolStripMenuItem,
            this.thêmMónToolStripMenuItem,
            this.thêmLoạiToolStripMenuItem});
            this.MToolStripMenuItem.Name = "MToolStripMenuItem";
            this.MToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.MToolStripMenuItem.Text = "Món";
            // 
            // tấtCảMónToolStripMenuItem
            // 
            this.tấtCảMónToolStripMenuItem.Name = "tấtCảMónToolStripMenuItem";
            this.tấtCảMónToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.tấtCảMónToolStripMenuItem.Text = "Tất cả món(sửa, xóa)";
            this.tấtCảMónToolStripMenuItem.Click += new System.EventHandler(this.tấtCảMónToolStripMenuItem_Click);
            // 
            // thêmMónToolStripMenuItem
            // 
            this.thêmMónToolStripMenuItem.Name = "thêmMónToolStripMenuItem";
            this.thêmMónToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.thêmMónToolStripMenuItem.Text = "Thêm món";
            this.thêmMónToolStripMenuItem.Click += new System.EventHandler(this.thêmMónToolStripMenuItem_Click);
            // 
            // thêmLoạiToolStripMenuItem
            // 
            this.thêmLoạiToolStripMenuItem.Name = "thêmLoạiToolStripMenuItem";
            this.thêmLoạiToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.thêmLoạiToolStripMenuItem.Text = "Thêm, xóa loại";
            this.thêmLoạiToolStripMenuItem.Click += new System.EventHandler(this.thêmLoạiToolStripMenuItem_Click);
            // 
            // KHToolStripMenuItem
            // 
            this.KHToolStripMenuItem.Name = "KHToolStripMenuItem";
            this.KHToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.KHToolStripMenuItem.Text = "Khách hàng";
            this.KHToolStripMenuItem.Click += new System.EventHandler(this.KHToolStripMenuItem_Click);
            // 
            // NVToolStripMenuItem
            // 
            this.NVToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tấtCảSửaXóaToolStripMenuItem,
            this.thêmNhânViênToolStripMenuItem});
            this.NVToolStripMenuItem.Name = "NVToolStripMenuItem";
            this.NVToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.NVToolStripMenuItem.Text = "Nhân viên";
            // 
            // tấtCảSửaXóaToolStripMenuItem
            // 
            this.tấtCảSửaXóaToolStripMenuItem.Name = "tấtCảSửaXóaToolStripMenuItem";
            this.tấtCảSửaXóaToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.tấtCảSửaXóaToolStripMenuItem.Text = "Tất cả  nhân viên (sửa, xóa)";
            this.tấtCảSửaXóaToolStripMenuItem.Click += new System.EventHandler(this.tấtCảSửaXóaToolStripMenuItem_Click);
            // 
            // thêmNhânViênToolStripMenuItem
            // 
            this.thêmNhânViênToolStripMenuItem.Name = "thêmNhânViênToolStripMenuItem";
            this.thêmNhânViênToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.thêmNhânViênToolStripMenuItem.Text = "Thêm nhân viên";
            this.thêmNhânViênToolStripMenuItem.Click += new System.EventHandler(this.thêmNhânViênToolStripMenuItem_Click);
            // 
            // InfoToolStripMenuItem
            // 
            this.InfoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đổiMậtKhẩuToolStripMenuItem});
            this.InfoToolStripMenuItem.Name = "InfoToolStripMenuItem";
            this.InfoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.InfoToolStripMenuItem.Text = "Thông tin cá nhân";
            // 
            // đổiMậtKhẩuToolStripMenuItem
            // 
            this.đổiMậtKhẩuToolStripMenuItem.Name = "đổiMậtKhẩuToolStripMenuItem";
            this.đổiMậtKhẩuToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.đổiMậtKhẩuToolStripMenuItem.Text = "Đổi mật khẩu";
            this.đổiMậtKhẩuToolStripMenuItem.Click += new System.EventHandler(this.đổiMậtKhẩuToolStripMenuItem_Click);
            // 
            // ExitToolStripMenuItem
            // 
            this.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
            this.ExitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ExitToolStripMenuItem.Text = "Thoát";
            this.ExitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1,
            this.toolStripDropDownButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(763, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewHlepToolStripMenuItem});
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(45, 22);
            this.toolStripDropDownButton2.Text = "Help";
            // 
            // viewHlepToolStripMenuItem
            // 
            this.viewHlepToolStripMenuItem.Name = "viewHlepToolStripMenuItem";
            this.viewHlepToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.viewHlepToolStripMenuItem.Text = "View hlep";
            this.viewHlepToolStripMenuItem.Click += new System.EventHandler(this.viewHlepToolStripMenuItem_Click);
            // 
            // dGVRevenue
            // 
            this.dGVRevenue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVRevenue.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.name,
            this.sdt,
            this.money,
            this.Column1,
            this.point});
            this.dGVRevenue.Location = new System.Drawing.Point(-3, 3);
            this.dGVRevenue.Name = "dGVRevenue";
            this.dGVRevenue.ReadOnly = true;
            this.dGVRevenue.Size = new System.Drawing.Size(763, 305);
            this.dGVRevenue.TabIndex = 7;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Width = 40;
            // 
            // name
            // 
            this.name.DataPropertyName = "Tên khách hàng";
            this.name.HeaderText = "Tên khách hàng";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            this.name.Width = 200;
            // 
            // sdt
            // 
            this.sdt.DataPropertyName = "Số điện thoại";
            this.sdt.HeaderText = "Số điện thoại";
            this.sdt.Name = "sdt";
            this.sdt.ReadOnly = true;
            this.sdt.Width = 150;
            // 
            // money
            // 
            this.money.DataPropertyName = "Tiền";
            this.money.HeaderText = "Tiền";
            this.money.Name = "money";
            this.money.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Ngày thanh toán";
            this.Column1.HeaderText = "Ngày thanh toán";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 130;
            // 
            // point
            // 
            this.point.DataPropertyName = "Điểm tích lũy";
            this.point.HeaderText = "Điểm tích lũy";
            this.point.Name = "point";
            this.point.ReadOnly = true;
            // 
            // tbDTRevenue
            // 
            this.tbDTRevenue.Location = new System.Drawing.Point(571, 317);
            this.tbDTRevenue.Name = "tbDTRevenue";
            this.tbDTRevenue.Size = new System.Drawing.Size(180, 20);
            this.tbDTRevenue.TabIndex = 8;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(484, 318);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(81, 16);
            this.label18.TabIndex = 9;
            this.label18.Text = "Doanh thu:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dGVRevenue);
            this.panel1.Controls.Add(this.tbDTRevenue);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Location = new System.Drawing.Point(0, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(763, 347);
            this.panel1.TabIndex = 10;
            // 
            // fAdminManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(763, 374);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "fAdminManager";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormAdmin";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVRevenue)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem TKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem InfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.DataGridView dGVRevenue;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn sdt;
        private System.Windows.Forms.DataGridViewTextBoxColumn money;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn point;
        private System.Windows.Forms.TextBox tbDTRevenue;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ToolStripMenuItem ngàyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tuầnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoNgàyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoTuầnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoThàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nămToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem theoQuýToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem viewHlepToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tấtCảMónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmLoạiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmMónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem KHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem NVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tấtCảSửaXóaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmNhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đổiMậtKhẩuToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
    }
}