﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAKERY_MANAGER
{
    public partial class fChangePass : Form
    {
        Models.BakeryManeger context = new Models.BakeryManeger();
        string tmp;
        public fChangePass()
        {
            InitializeComponent();
        }
        public void loadInfo(TextBox tbx)
        {
            tmp = tbx.Text;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            Models.AccountInfo a = context.AccountInfoes.FirstOrDefault(p => p.displayName == tmp);
            Models.Account acc = context.Accounts.FirstOrDefault(p => p.userName == a.userName);
            if (tbxOldPass.Text == acc.passWord)
            {
                if (tbxNewPass.Text == tbxReEnterPass.Text)
                {
                    acc.passWord = tbxNewPass.Text;
                    context.SaveChanges();
                    MessageBox.Show("Đổi thành công!!!");
                }
                else
                {
                    MessageBox.Show("Mật khẩu không khớp");
                }
            }
            else
            {
                MessageBox.Show("Sai mật khẩu");
            }    
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
