﻿using BAKERY_MANAGER.Function;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAKERY_MANAGER
{
    public partial class Staff : Form
    {
        public Staff()
        {
            InitializeComponent();
            DataStaff();
            detailStaff();
        }
        public void DataStaff()
        {
            string query = "select Account.userName as N'Tên tài khoảng',displayName as N'Tên nhân viên'," +
                "Phone as N'Số điện thoại', Salary as N'Lương',address as N'Địa chỉ' from AccountInfo, " +
                "Account where Account.userName = AccountInfo.userName and Account.type = 0";
            queryData dataStaff = new queryData();
            dGVStaff.DataSource = dataStaff.dataTable(query);
        }
        void StaffNull()
        {
            tbNVName.Text = "";
            tbNVDisplayName.Text = "";
            tbNVAdress.Text = "";
            tbNVNumberPhone.Text = "";
            tbNVSalary.Text = "";
        }
        void detailStaff()
        {
            tbNVName.DataBindings.Clear();
            tbNVDisplayName.DataBindings.Clear();
            tbNVAdress.DataBindings.Clear();
            tbNVNumberPhone.DataBindings.Clear();
            tbNVSalary.DataBindings.Clear();

            tbNVName.DataBindings.Add(new Binding("Text", dGVStaff.DataSource, "Tên tài khoảng", true, DataSourceUpdateMode.Never));
            tbNVDisplayName.DataBindings.Add(new Binding("Text", dGVStaff.DataSource, "Tên nhân viên", true, DataSourceUpdateMode.Never));
            tbNVNumberPhone.DataBindings.Add(new Binding("Text", dGVStaff.DataSource, "Số điện thoại", true, DataSourceUpdateMode.Never));
            tbNVAdress.DataBindings.Add(new Binding("Text", dGVStaff.DataSource, "Địa chỉ", true, DataSourceUpdateMode.Never));
            tbNVSalary.DataBindings.Add(new Binding("Text", dGVStaff.DataSource, "Lương", true, DataSourceUpdateMode.Never));
        }
        private void btStaffSearch_Click(object sender, EventArgs e)
        {
            string name = tbStaffSearch.Text;
            string query = string.Format("select Account.userName as N'Tên tài khoảng',displayName as N'Tên nhân viên'," +
                "Phone as N'Số điện thoại', Salary as N'Lương',address as N'Địa chỉ' from AccountInfo, " +
                "Account where Account.userName = AccountInfo.userName and Account.type = 0 and displayName like N'%{0}%'", name);
            queryData data = new queryData();
            dGVStaff.DataSource = data.dataTable(query);
            if (dGVStaff.Rows.Count > 1)
            {
                detailStaff();
                MessageBox.Show("Tìm kiếm thánh công!");
            }
            else
            {
                StaffNull();
                MessageBox.Show("Không tìm thấy nhân viên có tên: " + name);
            }
        }

        private void btStaffRemove_Click(object sender, EventArgs e)
        {
            string userName = tbNVName.Text;
            string delete = string.Format("delete from AccountInfo where userName='{0}'", userName);
            string delete1 = string.Format("delete from Account where userName='{0}'", userName);
            queryData data = new queryData();
            queryData data1 = new queryData();
            data.AddOrFixOrDelete(delete);
            data1.AddOrFixOrDelete(delete1);
            MessageBox.Show("Đã xóa " + userName + " thành công!");
            DataStaff();
            detailStaff();
        }

        private void btStaffFix_Click(object sender, EventArgs e)
        {
            string name = tbNVName.Text;
            string displayname = tbNVDisplayName.Text;
            string phoneNumber = tbNVNumberPhone.Text;
            string adress = tbNVAdress.Text;
            string salary = tbNVSalary.Text;
            string query = string.Format("update AccountInfo set displayName=N'{0}',address=N'{1}'," +
                "Phone=N'{2}',Salary={3} where userName=N'{4}'", displayname, adress, phoneNumber, salary, name);
            queryData data = new queryData();
            data.AddOrFixOrDelete(query);
            MessageBox.Show("Đã sửa thành công thông tin nhân viên " + displayname + "!");
            DataStaff();
            detailStaff();
        }

        private void btRefreshPass_Click(object sender, EventArgs e)
        {
            string name = tbNVName.Text;
            string query = string.Format("update Account set passWord=123456 where userName=N'{0}'", name);
            queryData data = new queryData();
            data.AddOrFixOrDelete(query);
            MessageBox.Show("Đặt lại mật khẩu thành công!");
        }
    }
}
