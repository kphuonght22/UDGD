﻿using BAKERY_MANAGER.Function;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAKERY_MANAGER
{
    public partial class DTProduct : Form
    {
        public DTProduct()
        {
            InitializeComponent();
        }


        private void btTKM_Click_1(object sender, EventArgs e)
        {
            string d, m, y, d1, m1, y1;
            d = dateTimePicker1.Value.Day.ToString();
            m = dateTimePicker1.Value.Month.ToString();
            y = dateTimePicker2.Value.Year.ToString();
            int dd = dateTimePicker2.Value.Day + 1;
            d1 = dd.ToString();
            m1 = dateTimePicker2.Value.Month.ToString();
            y1 = dateTimePicker2.Value.Year.ToString();
            string key = cbTKHClassify.Text;
            string dayStart = y + "/" + m + "/" + d;
            string dayEnd = y1 + "/" + m1 + "/" + d1;
            queryData data = new queryData();

            if (key == "")
            {
                string query = string.Format("select Food.id as N'ID', Food.name as N'Tên loại',SUM(BillInfo.count) " +
                    "as N'Số lượng',SUM(bPrice) as N'Tổng tiền' from BillInfo, Bill, Food " +
                    "where Food.id = BillInfo.idFood and Bill.id = BillInfo.idBill and timePay >= '{0}' " +
                    "and timePay <= '{1}' group by Food.name,Food.id", dayStart, dayEnd);
                dataGridView1.DataSource = data.dataTable(query);
                if (dataGridView1.Rows.Count < 2) MessageBox.Show("Chưa bán được mặt hàng nào!");
            }
            else
            {
                string query = string.Format("select Food.id as N'ID', Food.name as N'Tên loại'," +
                    "SUM(BillInfo.count) as N'Số lượng',SUM(bPrice) as N'Tổng tiền' " +
                    "from BillInfo, Bill, Food, FoodCategory where Food.id = BillInfo.idFood and " +
                    "Bill.id = BillInfo.idBill and timePay >= '{0}' and timePay <= '{1}' and " +
                    "Food.idCategory = FoodCategory.id and FoodCategory.name = N'{2}' group by Food.name, " +
                    "Food.id", dayStart, dayEnd, key);
                dataGridView1.DataSource = data.dataTable(query);
                if (dataGridView1.Rows.Count < 2) MessageBox.Show("Chưa bán được mặt hàng nào!");
            }

            textBox1.DataBindings.Clear();
            textBox2.DataBindings.Clear();
            textBox3.DataBindings.Clear();
            textBox4.DataBindings.Clear();

            textBox1.DataBindings.Add(new Binding("Text", dataGridView1.DataSource, "ID", true, DataSourceUpdateMode.Never));
            textBox2.DataBindings.Add(new Binding("Text", dataGridView1.DataSource, "Tên loại", true, DataSourceUpdateMode.Never));
            textBox3.DataBindings.Add(new Binding("Text", dataGridView1.DataSource, "Số lượng", true, DataSourceUpdateMode.Never));
            textBox4.DataBindings.Add(new Binding("Text", dataGridView1.DataSource, "Tổng tiền", true, DataSourceUpdateMode.Never));
        }

        private void DTProduct_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bAKERYDataSet3.FoodCategory' table. You can move, or remove it, as needed.
            this.foodCategoryTableAdapter.Fill(this.bAKERYDataSet3.FoodCategory);

        }
    }
}
