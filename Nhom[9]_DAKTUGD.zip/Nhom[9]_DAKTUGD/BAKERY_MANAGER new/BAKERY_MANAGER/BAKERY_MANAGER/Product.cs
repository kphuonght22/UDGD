﻿using BAKERY_MANAGER.Function;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAKERY_MANAGER
{
    public partial class Product : Form
    {
        public Product()
        {
            InitializeComponent();
            load();
            detailProduct();
        }
        void load()
        {
            string query = "select Food.id as N'ID',food.name as N'Tên món',FoodCategory.name as N'Loại'," +
                "price as N'Giá bán',describe as N'Mô tả' from Food, FoodCategory where idCategory = FoodCategory.id";
            queryData dataProduct = new queryData();
            dGVProduct.DataSource = dataProduct.dataTable(query);
        }
        void ProductNull()
        {
            tbSPID.Text = "";
            tbSPNameFood.Text = "";
            tbSPPrice.Text = "";
            tbProductDescribe.Text = "";
        }
        void detailProduct()
        {
            tbSPNameFood.DataBindings.Clear();
            tbSPID.DataBindings.Clear();
            tbSPPrice.DataBindings.Clear();
            cbProductClassify.DataBindings.Clear();
            tbProductDescribe.DataBindings.Clear();

            cbProductClassify.DataBindings.Add(new Binding("Text", dGVProduct.DataSource, "Loại", true, DataSourceUpdateMode.Never));
            tbSPNameFood.DataBindings.Add(new Binding("Text", dGVProduct.DataSource, "Tên món", true, DataSourceUpdateMode.Never));
            tbSPID.DataBindings.Add(new Binding("Text", dGVProduct.DataSource, "ID", true, DataSourceUpdateMode.Never));
            tbSPPrice.DataBindings.Add(new Binding("Text", dGVProduct.DataSource, "Giá bán", true, DataSourceUpdateMode.Never));
            tbProductDescribe.DataBindings.Add(new Binding("Text", dGVProduct.DataSource, "Mô tả", true, DataSourceUpdateMode.Never));
        }
        private void btProductFix_Click(object sender, EventArgs e)
        {
            string id = tbSPID.Text;
            string name = tbSPNameFood.Text;
            string classify = cbProductClassify.Text;
            string price = tbSPPrice.Text;
            string describe=tbProductDescribe.Text;

            string query1 = string.Format("select FoodCategory.id from FoodCategory where name = N'{0}'", classify);
            queryData data1 = new queryData();
            classify = data1.TextBox(query1);
            string query = string.Format("update Food set name=N'{0}',idCategory={1},price={2},describe=N'{3}' where id={4}", name, classify, price, describe, id);
            queryData data = new queryData();
            data.AddOrFixOrDelete(query);
            MessageBox.Show("Đã sửa thành công!");
            load();
            detailProduct();
        }

        private void btProductRemove_Click(object sender, EventArgs e)
        {
            string ID = tbSPID.Text;
            string name = tbSPNameFood.Text;
            string delete = string.Format("delete from Food where id={0}", ID);
            queryData data = new queryData();
            data.AddOrFixOrDelete(delete);
            MessageBox.Show("Đã xóa " + name + " thành công! Vui lòng cập nhật..");
            load();
            detailProduct();
        }


        private void btProductSearch_Click(object sender, EventArgs e)
        {
            string name = tbProductSearch.Text;
            string query = "select Food.id as N'ID',Food.name as N'Tên món',FoodCategory.name as N'Loại',price as N'Giá bán', describe as N'Mô tả' from Food,FoodCategory" +
                " where Food.name like N'%" + name + "%' and Food.idcategory=FoodCategory.id";
            queryData data = new queryData();
            dGVProduct.DataSource = data.dataTable(query);
            if (dGVProduct.Rows.Count > 1)
            {
                detailProduct();
                MessageBox.Show("Tìm kiếm thành công!");
            }
            else
            {
                ProductNull();
                MessageBox.Show("Không tìm thấy món có tên: " + name);
            }
        }

        private void Product_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bAKERYDataSet2.FoodCategory' table. You can move, or remove it, as needed.
            this.foodCategoryTableAdapter1.Fill(this.bAKERYDataSet2.FoodCategory);

        }
    }
}
