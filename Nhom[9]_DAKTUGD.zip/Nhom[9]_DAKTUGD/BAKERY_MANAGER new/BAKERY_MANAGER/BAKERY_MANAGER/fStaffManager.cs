﻿using BAKERY_MANAGER.Models;
using BakeryManeger;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BakeryManeger
{
    public partial class fStaffManager : Form
    {
        Timer tmr = null;
        BAKERY_MANAGER.Models.BakeryManeger context = new BAKERY_MANAGER.Models.BakeryManeger();
        public fStaffManager()
        {
            InitializeComponent();

            loadTime();
            loadFood();
            loadFoodCategory();
            loadIDBill();
        }
        public delegate void delPassData(TextBox text);
        public void loadStaffName(TextBox txtForm1)
        {
            AccountInfo a = context.AccountInfoes.FirstOrDefault(p => p.userName == txtForm1.Text);
            tbxStaffName.Text = a.displayName;
        }
        void loadTime()
        {
            tmr = new Timer();
            tmr.Interval = 1000;
            tmr.Tick += new EventHandler(tmr_Tick);
            tmr.Enabled = true;
        }
        void loadFood()
        {
            lsvFood.Items.Clear();
            List<Food> listFood = context.Foods.ToList();
            foreach (Food fd in listFood)
            {
                string[] a = new string[]
                {
                    fd.id.ToString(),
                    fd.name,
                    fd.price.ToString()
                };
                ListViewItem lvItem = new ListViewItem(a);
                lsvFood.Items.Add(lvItem);
            }
        }
        void loadFoodCategory()
        {
            List<FoodCategory> listFoodCategory = context.FoodCategories.ToList();
            cbxFoodCategory.Items.Add("Toàn bộ");
            foreach (FoodCategory f in listFoodCategory)
            {
                cbxFoodCategory.Items.Add(f.name);
            }
        }
        void loadIDBill()
        {
            int idBill = context.Bills.Max(p => p.id);
            tbxIdBill.Text = (idBill + 1).ToString();
        }
        void resetAll()
        {
            loadIDBill();

            tbxCheckPhone.Text = "";
            tbxCheckPhone.ReadOnly = true;
            cbxCustomer.Checked = false;
            tbxPoint.Text = "";
            numSale.Value = 0;
            tbxThanhTien.Text = "0";

            lvsBill.Items.Clear();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #region Event
        void tmr_Tick(object sender, EventArgs e)
        {
            tbxTime.Text = DateTime.Now.ToString();
        }
        private void itemAccountInfo_Click(object sender, EventArgs e)
        {
            fAccountInformation fAcc = new fAccountInformation();
            delPassData del = new delPassData(fAcc.loadInfomation);
            del(this.tbxStaffName);
            fAcc.ShowDialog();
        }

        private void itemChangePass_Click(object sender, EventArgs e)
        {
            BAKERY_MANAGER.fChangePass f = new BAKERY_MANAGER.fChangePass();
            delPassData del = new delPassData(f.loadInfo);
            del(this.tbxStaffName);
            f.ShowDialog();
        }

        private void itemExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void itemAddAccount_Click(object sender, EventArgs e)
        {
            BAKERY_MANAGER.fAddAccountCustomer f = new BAKERY_MANAGER.fAddAccountCustomer();
            f.ShowDialog();
        }
        #endregion

        private void btnAddFood_Click(object sender, EventArgs e)
        {
            if (lsvFood.SelectedItems.Count <= 0)
            {
                MessageBox.Show("Bạn chưa chọn món!");
            }
            else
            {
                ListViewItem item = lsvFood.SelectedItems[0];
                int tongGia = (int)(int.Parse(item.SubItems[2].Text) * amount.Value);
                string[] a = new string[]
                {
                    item.SubItems[1].Text,
                    item.SubItems[2].Text,
                    amount.Value.ToString(),
                    tongGia.ToString()
                };
                ListViewItem items = new ListViewItem(a);
                lvsBill.Items.Add(items);
                amount.Value = 1;
                int tmp = int.Parse(tbxThanhTien.Text);
                tbxThanhTien.Text = (tmp + tongGia).ToString();
            }
        }

        private void cbxFoodCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            lsvFood.Items.Clear();
            List<Food> listFood = context.Foods.ToList();
            FoodCategory fCategory = context.FoodCategories.FirstOrDefault(p => p.name == cbxFoodCategory.Text);
            if (fCategory != null)
            {
                foreach (Food f in listFood)
                {
                    if (f.idCategory == fCategory.id)
                    {
                        string[] a = new string[]
                        {
                            f.id.ToString(),
                            f.name,
                            f.price.ToString()
                        };
                        ListViewItem lvItem = new ListViewItem(a);
                        lsvFood.Items.Add(lvItem);
                    }
                }
            }
            else { loadFood(); }
        }

        private void btnClearBill_Click(object sender, EventArgs e)
        {
            lvsBill.Items.Clear();
            tbxThanhTien.Text = "0";
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            if (tbxThanhTien != null)
            {
                int customer = 1;
                if (cbxCustomer.Checked)
                {
                    Customer a = context.Customers.FirstOrDefault(p => p.phone.ToString() == tbxCheckPhone.Text);
                    customer = a.id;
                    a.point = int.Parse(tbxPoint.Text);
                    a.point += (int.Parse(tbxThanhTien.Text) / 50000) * 50;
                    context.SaveChanges();
                }
                //tao bill ms
                Bill b = new Bill()
                {
                    idCustomer = customer,
                    timePay = DateTime.Now,
                    moneyPay = int.Parse(tbxThanhTien.Text)
                };
                context.Bills.Add(b);
                //tạo bill info ms
                foreach (ListViewItem item in lvsBill.Items)
                {
                    string tmp = item.SubItems[0].Text;
                    Food f = context.Foods.FirstOrDefault(p => p.name == tmp);
                    BillInfo bf = new BillInfo()
                    {
                        idBill = int.Parse(tbxIdBill.Text),
                        idFood = f.id,
                        count = int.Parse(item.SubItems[2].Text),
                        bPrice = int.Parse(item.SubItems[3].Text)
                    };
                    context.BillInfoes.Add(bf);
                }
                context.SaveChanges();
            }
            int thuTien = (int)(int.Parse(tbxThanhTien.Text) - int.Parse(tbxThanhTien.Text) * numSale.Value / 100);
            MessageBox.Show("Thu tiền: " + thuTien.ToString());
            resetAll();
        }
        private void cbxCustomer_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxCustomer.Checked)
            {
                tbxCheckPhone.ReadOnly = false;
            }
            else
            {
                tbxCheckPhone.ReadOnly = true;
                tbxPoint.Text = "";
            }
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            if (cbxCustomer.Checked)
            {
                Customer a = context.Customers.FirstOrDefault(p => p.phone.ToString() == tbxCheckPhone.Text);
                if (a != null)
                {
                    MessageBox.Show(a.name);
                    tbxPoint.Text = a.point.ToString();
                }
                else
                {
                    MessageBox.Show("Số điện thoại không tồn tại");
                    tbxCheckPhone.Text = "";
                    cbxCustomer.Checked = false;
                }
            }
        }
        private void numSale_ValueChanged(object sender, EventArgs e)
        {
            if (cbxCustomer.Checked)
            {
                Customer a = context.Customers.FirstOrDefault(p => p.phone.ToString() == tbxCheckPhone.Text);
                if (a.point - numSale.Value * 100 >= 0)
                {
                    tbxPoint.Text = (a.point - numSale.Value * 100).ToString();
                }
            }
        }

        private void btnSearchFood_Click(object sender, EventArgs e)
        {
            lsvFood.Items.Clear();
            List<Food> listFood = context.Foods.ToList();
            foreach (Food f in listFood)
            {
                if (f.name.ToUpper().Contains(tbxSearchFood.Text.ToUpper()))
                {
                    string[] a = new string[]
                    {
                       f.id.ToString(),
                       f.name,
                       f.price.ToString()
                    };
                    ListViewItem lvItem = new ListViewItem(a);
                    lsvFood.Items.Add(lvItem);
                }
            }
        }
    }
}
