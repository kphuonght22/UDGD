﻿namespace BAKERY_MANAGER
{
    partial class AddFood
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.tbSPNameFood = new System.Windows.Forms.TextBox();
            this.cbProductClassify = new System.Windows.Forms.ComboBox();
            this.foodCategoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bAKERYDataSet1 = new BAKERY_MANAGER.BAKERYDataSet1();
            this.foodCategoryTableAdapter = new BAKERY_MANAGER.BAKERYDataSet1TableAdapters.FoodCategoryTableAdapter();
            this.tbSPPrice = new System.Windows.Forms.TextBox();
            this.tbProductDescribe = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btAddProductOk = new System.Windows.Forms.Button();
            this.btAddProductCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.foodCategoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bAKERYDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(76, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 38);
            this.label1.TabIndex = 13;
            this.label1.Text = "THÊM MÓN";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbSPNameFood
            // 
            this.tbSPNameFood.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSPNameFood.Location = new System.Drawing.Point(120, 74);
            this.tbSPNameFood.Name = "tbSPNameFood";
            this.tbSPNameFood.Size = new System.Drawing.Size(208, 22);
            this.tbSPNameFood.TabIndex = 14;
            // 
            // cbProductClassify
            // 
            this.cbProductClassify.DataSource = this.foodCategoryBindingSource;
            this.cbProductClassify.DisplayMember = "name";
            this.cbProductClassify.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbProductClassify.FormattingEnabled = true;
            this.cbProductClassify.Location = new System.Drawing.Point(120, 132);
            this.cbProductClassify.Name = "cbProductClassify";
            this.cbProductClassify.Size = new System.Drawing.Size(208, 24);
            this.cbProductClassify.TabIndex = 17;
            this.cbProductClassify.ValueMember = "name";
            // 
            // foodCategoryBindingSource
            // 
            this.foodCategoryBindingSource.DataMember = "FoodCategory";
            this.foodCategoryBindingSource.DataSource = this.bAKERYDataSet1;
            // 
            // bAKERYDataSet1
            // 
            this.bAKERYDataSet1.DataSetName = "BAKERYDataSet1";
            this.bAKERYDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // foodCategoryTableAdapter
            // 
            this.foodCategoryTableAdapter.ClearBeforeFill = true;
            // 
            // tbSPPrice
            // 
            this.tbSPPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSPPrice.Location = new System.Drawing.Point(120, 199);
            this.tbSPPrice.Multiline = true;
            this.tbSPPrice.Name = "tbSPPrice";
            this.tbSPPrice.Size = new System.Drawing.Size(208, 22);
            this.tbSPPrice.TabIndex = 19;
            // 
            // tbProductDescribe
            // 
            this.tbProductDescribe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbProductDescribe.Location = new System.Drawing.Point(120, 262);
            this.tbProductDescribe.Multiline = true;
            this.tbProductDescribe.Name = "tbProductDescribe";
            this.tbProductDescribe.Size = new System.Drawing.Size(208, 91);
            this.tbProductDescribe.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 16);
            this.label4.TabIndex = 21;
            this.label4.Text = "Tên món:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(12, 135);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(42, 16);
            this.label17.TabIndex = 22;
            this.label17.Text = "Loại:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 202);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 16);
            this.label5.TabIndex = 23;
            this.label5.Text = "Giá:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(12, 302);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 16);
            this.label19.TabIndex = 24;
            this.label19.Text = "Mô tải:";
            // 
            // btAddProductOk
            // 
            this.btAddProductOk.Location = new System.Drawing.Point(228, 371);
            this.btAddProductOk.Name = "btAddProductOk";
            this.btAddProductOk.Size = new System.Drawing.Size(100, 36);
            this.btAddProductOk.TabIndex = 25;
            this.btAddProductOk.Text = "OK";
            this.btAddProductOk.UseVisualStyleBackColor = true;
            this.btAddProductOk.Click += new System.EventHandler(this.btAddProductOk_Click);
            // 
            // btAddProductCancel
            // 
            this.btAddProductCancel.Location = new System.Drawing.Point(36, 371);
            this.btAddProductCancel.Name = "btAddProductCancel";
            this.btAddProductCancel.Size = new System.Drawing.Size(100, 36);
            this.btAddProductCancel.TabIndex = 26;
            this.btAddProductCancel.Text = "Cancel";
            this.btAddProductCancel.UseVisualStyleBackColor = true;
            this.btAddProductCancel.Click += new System.EventHandler(this.btAddProductCancel_Click);
            // 
            // AddFood
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 419);
            this.Controls.Add(this.btAddProductCancel);
            this.Controls.Add(this.btAddProductOk);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbProductDescribe);
            this.Controls.Add(this.tbSPPrice);
            this.Controls.Add(this.cbProductClassify);
            this.Controls.Add(this.tbSPNameFood);
            this.Controls.Add(this.label1);
            this.Name = "AddFood";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm món";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.foodCategoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bAKERYDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbSPNameFood;
        private System.Windows.Forms.ComboBox cbProductClassify;
        private BAKERYDataSet1 bAKERYDataSet1;
        private System.Windows.Forms.BindingSource foodCategoryBindingSource;
        private BAKERYDataSet1TableAdapters.FoodCategoryTableAdapter foodCategoryTableAdapter;
        private System.Windows.Forms.TextBox tbSPPrice;
        private System.Windows.Forms.TextBox tbProductDescribe;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btAddProductOk;
        private System.Windows.Forms.Button btAddProductCancel;
    }
}