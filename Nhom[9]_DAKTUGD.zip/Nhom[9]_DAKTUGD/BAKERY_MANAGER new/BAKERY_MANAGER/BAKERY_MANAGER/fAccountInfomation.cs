﻿using BakeryManeger;
using BAKERY_MANAGER.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BakeryManeger
{
    public partial class fAccountInformation : Form
    {
        BAKERY_MANAGER.Models.BakeryManeger context = new BAKERY_MANAGER.Models.BakeryManeger();
        public fAccountInformation()
        {
            InitializeComponent();
        }
        public void loadInfomation(TextBox txtForm1)
        {
            AccountInfo a = context.AccountInfoes.FirstOrDefault(p => p.displayName == txtForm1.Text);
            tbxUserName.Text = a.userName;
            tbxDisplayName.Text = a.displayName;
            tbxAddress.Text = a.address;
            tbxPhone.Text = a.phone;
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (tbxPhone.Text == "" || tbxAddress.Text == "" || tbxDisplayName.Text == "" || tbxUserName.Text == "")
            {
                MessageBox.Show("Điền đầy đủ thông tin");
            }
            else
            {
                AccountInfo a = context.AccountInfoes.FirstOrDefault(p => p.userName == tbxUserName.Text);
                a.userName = tbxUserName.Text;
                a.displayName = tbxDisplayName.Text;
                a.address = tbxAddress.Text;
                a.phone = tbxPhone.Text;
                context.SaveChanges();
                MessageBox.Show("Thành công");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
