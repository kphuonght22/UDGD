﻿using BAKERY_MANAGER.Function;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAKERY_MANAGER
{
    public partial class AddFood : Form
    {
        public AddFood()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bAKERYDataSet1.FoodCategory' table. You can move, or remove it, as needed.
            this.foodCategoryTableAdapter.Fill(this.bAKERYDataSet1.FoodCategory);

        }

        private void btAddProductOk_Click(object sender, EventArgs e)
        {
            string name = tbSPNameFood.Text;
            string classily = cbProductClassify.Text;
            string price = tbSPPrice.Text;
            string describe = tbProductDescribe.Text;
            string query1 = string.Format("select FoodCategory.id from FoodCategory where name = N'{0}'", classily);
            queryData data = new queryData();
            classily = data.TextBox(query1);
            string query = string.Format("INSERT INTO Food(name,idCategory,price,describe) VALUES(N'{0}', {1}, {2}, N'{3}')", name, classily, price, describe);
            data.AddOrFixOrDelete(query);
            MessageBox.Show("Đã thêm " + name + " thành công!");
        }

        private void btAddProductCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
