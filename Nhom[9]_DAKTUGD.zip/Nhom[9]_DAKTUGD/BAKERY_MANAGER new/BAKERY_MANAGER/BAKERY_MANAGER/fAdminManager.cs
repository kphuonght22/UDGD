﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using BAKERY_MANAGER.Function;

namespace BAKERY_MANAGER
{
    public partial class fAdminManager : Form
    {
        private object openFileDialog1;

        public fAdminManager()
        {
            InitializeComponent();
            loadDT();
        }
        void loadDT()
        {
            string query = "select Bill.id as N'ID',Customer.name as N'Tên khách hàng',phone as N'Số điện thoại'," +
                " moneyPay as N'Tiền',timePay as N'Ngày thanh toán',point as N'Điểm tích lũy' from Bill," +
                " Customer where Bill.idCustomer = Customer.id";
            queryData data = new queryData();
            dGVRevenue.DataSource = data.dataTable(query);
            string query1 = "select SUM(moneyPay) from Bill";
            queryData data1 = new queryData();
            tbDTRevenue.Text = data1.TextBox(query1);
        }
        private void theoNgàyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string day = DateTime.Now.Day.ToString();
            string query = "select Bill.id as N'ID',Customer.name as N'Tên khách hàng',phone as N'Số điện thoại'," +
                " moneyPay as N'Tiền',timePay as N'Ngày thanh toán',point as N'Điểm tích lũy' from Bill," +
                " Customer where Bill.idCustomer = Customer.id and DAY(timePay)=" + day;
            queryData data = new queryData();
            dGVRevenue.DataSource = data.dataTable(query);
            string query1 = "select SUM(moneyPay) from Bill where DAY(timePay)=" + day;
            queryData data1 = new queryData();
            tbDTRevenue.Text = data1.TextBox(query1);
        }

        private void theoTuầnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int day = DateTime.Now.Day;
            int month = DateTime.Now.Month;
            int year = DateTime.Now.Year;
            if (day < 7)
            {
                day = Math.Abs(day - 30);
                if (month == 1)
                {
                    month = 12;
                    year--;
                }
                else month--;
            }
            else day -= 7;
            string query = string.Format("select Customer.id as N'ID', Customer.name as N'Tên khách hàng', " +
                "phone as N'Số điện thoại', Bill.moneyPay as N'Tiền', " +
                "timePay as N'Ngày thanh toán', point as N'Điểm tích lũy' from Customer, Bill " +
                "where Customer.id = Bill.idCustomer and YEAR(timePay) = {0} and MONTH(timePay) = {1} " +
                "and DAY(timePay) >= {2}", year.ToString(), month.ToString(), day.ToString());
            queryData data = new queryData();
            dGVRevenue.DataSource = data.dataTable(query);
            string query1 = string.Format("select SUM(moneyPay) from Bill where YEAR(timePay)={0} " +
                "and MONTH(timePay)={1} and DAY(timePay)>={2}", year, month, day);
            queryData data1 = new queryData();
            tbDTRevenue.Text = data1.TextBox(query1);
        }

        private void theoThàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string month = DateTime.Today.Month.ToString();
            string year = DateTime.Now.Year.ToString();

            string query = string.Format("select Bill.id as N'ID',Customer.name as N'Tên khách hàng'," +
                "phone as N'Số điện thoại', moneyPay as N'Tiền'," +
                "timePay as N'Ngày thanh toán',point as N'Điểm tích lũy' from Bill, " +
                "Customer where Bill.idCustomer=Customer.id and MONTH(timePay)={0} and YEAR(timePay)={1}", month, year);
            queryData data = new queryData();
            dGVRevenue.DataSource = data.dataTable(query);
            string query1 = string.Format("select SUM(moneyPay) from Bill where MONTH(timePay)={0} and YEAR(timePay)={1}", month, year);
            queryData data1 = new queryData();
            tbDTRevenue.Text = data1.TextBox(query1);
        }

        private void theoQuýToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int month = DateTime.Today.Month;
            string m1="", m2 = "";
            if (month > 1 && month < 4) m1 = "1";m2 = "3";
            if (month > 3 && month < 7) m1 = "4"; m2 = "6";
            if (month > 6 && month < 10) m1 = "7"; m2 = "9";
            if (month > 9 && month < 13) m1 = "10"; m2 = "12";

            string query = string.Format("select Bill.id as N'ID',Customer.name as N'Tên khách hàng'," +
                    "phone as N'Số điện thoại', moneyPay as N'Tiền'," +
                    "timePay as N'Ngày thanh toán',point as N'Điểm tích lũy' from Bill, " +
                    "Customer where Bill.idCustomer=Customer.id and MONTH(timePay) >= {0}and MONTH(timePay)<={1}", m1, m2);
            queryData data = new queryData();
            dGVRevenue.DataSource = data.dataTable(query);
            string query1 = string.Format("select SUM(moneyPay) from Bill where MONTH(timePay)>={0} and MONTH(timePay)<={1}", m1, m2);
            queryData data1 = new queryData();
            tbDTRevenue.Text = data1.TextBox(query1);
        }

        private void nămToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string year = DateTime.Now.Year.ToString();

            string query = string.Format("select Bill.id as N'ID',Customer.name as N'Tên khách hàng'," +
                "phone as N'Số điện thoại', moneyPay as N'Tiền'," +
                "timePay as N'Ngày thanh toán',point as N'Điểm tích lũy' from Bill, " +
                "Customer where Bill.idCustomer=Customer.id and YEAR(timePay)={0}", year);
            queryData data = new queryData();
            dGVRevenue.DataSource = data.dataTable(query);
            string query1 = string.Format("select SUM(moneyPay) from Bill where YEAR(timePay)={0}",  year);
            queryData data1 = new queryData();
            tbDTRevenue.Text = data1.TextBox(query1);
        }

        private void tuầnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DTProduct dTProduct = new DTProduct();
            dTProduct.ShowDialog();
        }


        //Product
        private void tấtCảMónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Product product = new Product();
            product.ShowDialog();
            loadDT();
        }

        private void thêmLoạiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddClassify addClassify = new AddClassify();
            addClassify.ShowDialog();
        }

        private void KHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.ShowDialog();
            loadDT();
        }

        private void thêmMónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddFood addFood = new AddFood();
            addFood.ShowDialog();
        }

        private void tấtCảSửaXóaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Staff staff = new Staff();
            staff.ShowDialog();
        }

        private void thêmNhânViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddStaff addStaff = new AddStaff();
            addStaff.ShowDialog();
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void đổiMậtKhẩuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangePassAdmin changePassAdmin = new ChangePassAdmin();
            changePassAdmin.ShowDialog();
        }

        private void viewHlepToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormHelp formHelp = new FormHelp();
            formHelp.ShowDialog();
        }

        
    }
}
