﻿namespace BAKERY_MANAGER
{
    partial class Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dGVStaff = new System.Windows.Forms.DataGridView();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbStaffSearch = new System.Windows.Forms.TextBox();
            this.btStaffSearch = new System.Windows.Forms.Button();
            this.tbNVName = new System.Windows.Forms.TextBox();
            this.tbNVDisplayName = new System.Windows.Forms.TextBox();
            this.tbNVNumberPhone = new System.Windows.Forms.TextBox();
            this.tbNVAdress = new System.Windows.Forms.TextBox();
            this.tbNVSalary = new System.Windows.Forms.TextBox();
            this.btStaffRemove = new System.Windows.Forms.Button();
            this.btStaffFix = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btRefreshPass = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dGVStaff)).BeginInit();
            this.SuspendLayout();
            // 
            // dGVStaff
            // 
            this.dGVStaff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVStaff.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column15,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19});
            this.dGVStaff.Location = new System.Drawing.Point(1, 5);
            this.dGVStaff.Name = "dGVStaff";
            this.dGVStaff.ReadOnly = true;
            this.dGVStaff.Size = new System.Drawing.Size(442, 396);
            this.dGVStaff.TabIndex = 1;
            // 
            // Column15
            // 
            this.Column15.DataPropertyName = "Tên tài khoảng";
            this.Column15.HeaderText = "Tên tài khoảng";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            // 
            // Column16
            // 
            this.Column16.DataPropertyName = "Tên nhân viên";
            this.Column16.HeaderText = "Tên nhân viên";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            // 
            // Column17
            // 
            this.Column17.DataPropertyName = "Số điện thoại";
            this.Column17.HeaderText = "Số điện thoại";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            // 
            // Column18
            // 
            this.Column18.DataPropertyName = "Lương";
            this.Column18.HeaderText = "Lương";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            // 
            // Column19
            // 
            this.Column19.DataPropertyName = "Địa chỉ";
            this.Column19.HeaderText = "Địa chỉ";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            // 
            // tbStaffSearch
            // 
            this.tbStaffSearch.Location = new System.Drawing.Point(566, 21);
            this.tbStaffSearch.Name = "tbStaffSearch";
            this.tbStaffSearch.Size = new System.Drawing.Size(222, 20);
            this.tbStaffSearch.TabIndex = 7;
            // 
            // btStaffSearch
            // 
            this.btStaffSearch.Location = new System.Drawing.Point(449, 13);
            this.btStaffSearch.Name = "btStaffSearch";
            this.btStaffSearch.Size = new System.Drawing.Size(111, 34);
            this.btStaffSearch.TabIndex = 8;
            this.btStaffSearch.Text = "Tìm kiếm";
            this.btStaffSearch.UseVisualStyleBackColor = true;
            this.btStaffSearch.Click += new System.EventHandler(this.btStaffSearch_Click);
            // 
            // tbNVName
            // 
            this.tbNVName.Location = new System.Drawing.Point(566, 82);
            this.tbNVName.Name = "tbNVName";
            this.tbNVName.ReadOnly = true;
            this.tbNVName.Size = new System.Drawing.Size(222, 20);
            this.tbNVName.TabIndex = 14;
            // 
            // tbNVDisplayName
            // 
            this.tbNVDisplayName.Location = new System.Drawing.Point(566, 139);
            this.tbNVDisplayName.Name = "tbNVDisplayName";
            this.tbNVDisplayName.Size = new System.Drawing.Size(222, 20);
            this.tbNVDisplayName.TabIndex = 15;
            // 
            // tbNVNumberPhone
            // 
            this.tbNVNumberPhone.Location = new System.Drawing.Point(566, 201);
            this.tbNVNumberPhone.Name = "tbNVNumberPhone";
            this.tbNVNumberPhone.Size = new System.Drawing.Size(222, 20);
            this.tbNVNumberPhone.TabIndex = 17;
            // 
            // tbNVAdress
            // 
            this.tbNVAdress.Location = new System.Drawing.Point(566, 256);
            this.tbNVAdress.Name = "tbNVAdress";
            this.tbNVAdress.Size = new System.Drawing.Size(222, 20);
            this.tbNVAdress.TabIndex = 27;
            // 
            // tbNVSalary
            // 
            this.tbNVSalary.Location = new System.Drawing.Point(566, 319);
            this.tbNVSalary.Name = "tbNVSalary";
            this.tbNVSalary.Size = new System.Drawing.Size(222, 20);
            this.tbNVSalary.TabIndex = 28;
            // 
            // btStaffRemove
            // 
            this.btStaffRemove.Location = new System.Drawing.Point(689, 359);
            this.btStaffRemove.Name = "btStaffRemove";
            this.btStaffRemove.Size = new System.Drawing.Size(99, 31);
            this.btStaffRemove.TabIndex = 29;
            this.btStaffRemove.Text = "Xóa";
            this.btStaffRemove.UseVisualStyleBackColor = true;
            this.btStaffRemove.Click += new System.EventHandler(this.btStaffRemove_Click);
            // 
            // btStaffFix
            // 
            this.btStaffFix.Location = new System.Drawing.Point(575, 359);
            this.btStaffFix.Name = "btStaffFix";
            this.btStaffFix.Size = new System.Drawing.Size(99, 31);
            this.btStaffFix.TabIndex = 30;
            this.btStaffFix.Text = "Sửa";
            this.btStaffFix.UseVisualStyleBackColor = true;
            this.btStaffFix.Click += new System.EventHandler(this.btStaffFix_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(449, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 16);
            this.label6.TabIndex = 31;
            this.label6.Text = "Tên tài khoảng:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(449, 140);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label7.Size = new System.Drawing.Size(109, 16);
            this.label7.TabIndex = 32;
            this.label7.Text = "Tên nhân viên:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(449, 205);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 16);
            this.label9.TabIndex = 33;
            this.label9.Text = "Số điện thoại:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(453, 257);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 16);
            this.label10.TabIndex = 34;
            this.label10.Text = "Địa chỉ:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(453, 320);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 16);
            this.label11.TabIndex = 35;
            this.label11.Text = "Lương:";
            // 
            // btRefreshPass
            // 
            this.btRefreshPass.Location = new System.Drawing.Point(456, 359);
            this.btRefreshPass.Name = "btRefreshPass";
            this.btRefreshPass.Size = new System.Drawing.Size(104, 31);
            this.btRefreshPass.TabIndex = 36;
            this.btRefreshPass.Text = "Đặt lại mật khẩu";
            this.btRefreshPass.UseVisualStyleBackColor = true;
            this.btRefreshPass.Click += new System.EventHandler(this.btRefreshPass_Click);
            // 
            // Staff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 402);
            this.Controls.Add(this.btRefreshPass);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btStaffFix);
            this.Controls.Add(this.btStaffRemove);
            this.Controls.Add(this.tbNVSalary);
            this.Controls.Add(this.tbNVAdress);
            this.Controls.Add(this.tbNVNumberPhone);
            this.Controls.Add(this.tbNVDisplayName);
            this.Controls.Add(this.tbNVName);
            this.Controls.Add(this.btStaffSearch);
            this.Controls.Add(this.tbStaffSearch);
            this.Controls.Add(this.dGVStaff);
            this.Name = "Staff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nhân viên";
            ((System.ComponentModel.ISupportInitialize)(this.dGVStaff)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dGVStaff;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.TextBox tbStaffSearch;
        private System.Windows.Forms.Button btStaffSearch;
        private System.Windows.Forms.TextBox tbNVName;
        private System.Windows.Forms.TextBox tbNVDisplayName;
        private System.Windows.Forms.TextBox tbNVNumberPhone;
        private System.Windows.Forms.TextBox tbNVAdress;
        private System.Windows.Forms.TextBox tbNVSalary;
        private System.Windows.Forms.Button btStaffRemove;
        private System.Windows.Forms.Button btStaffFix;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btRefreshPass;
    }
}