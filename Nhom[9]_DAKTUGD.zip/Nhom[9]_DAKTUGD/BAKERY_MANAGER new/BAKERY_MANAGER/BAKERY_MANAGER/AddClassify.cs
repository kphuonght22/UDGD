﻿using BAKERY_MANAGER.Function;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAKERY_MANAGER
{
    public partial class AddClassify : Form
    {
        public AddClassify()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string classify = textBox1.Text;
            if (classify == "")
            {
                MessageBox.Show("Vui lòng nhập tên loại");
            }
            else
            {
                string query = string.Format("INSERT INTO FoodCategory(name) VALUES(N'{0}')", classify);
                queryData data = new queryData();
                data.AddOrFixOrDelete(query);
                MessageBox.Show("Thêm loại " + classify + " thành công!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        

        private void AddClassify_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bAKERYDataSet3.FoodCategory' table. You can move, or remove it, as needed.
            this.foodCategoryTableAdapter.Fill(this.bAKERYDataSet3.FoodCategory);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string name = comboBox1.Text;
            
            if(MessageBox.Show("Bạn muốn xóa loại đang chọn và tất cả món liên quan?","Thông báo",MessageBoxButtons.OKCancel)== DialogResult.OK)
            {
                string query = string.Format("SELECT id FROM FoodCategory WHERE name=N'{0}'", name);
                queryData data = new queryData();
                string id = data.TextBox(query);
                // lấy id từ bảng foodcategory
                //xóa trong bảng food
                string deleteFood = string.Format("DELETE FROM Food WHERE idCategory={0}", id);
                queryData data1 = new queryData();
                data1.AddOrFixOrDelete(deleteFood);
                // xóa trong bảng foodcategory

                string deleteFoodCategory = string.Format("DELETE FROM FoodCategory WHERE name=N'{0}'", name);
                queryData data2 = new queryData();
                data2.AddOrFixOrDelete(deleteFoodCategory);
                MessageBox.Show("Xóa thành công!");
            }
        }
    }
}
