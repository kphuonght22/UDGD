﻿using BAKERY_MANAGER.Function;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAKERY_MANAGER
{
    public partial class AddStaff : Form
    {
        public AddStaff()
        {
            InitializeComponent();
        }

        private void btstaffAddOk_Click(object sender, EventArgs e)
        {
            string name = tbNVName.Text;
            string displayname = tbNVDisplayName.Text;
            string phoneNumber = tbNVNumberPhone.Text;
            string adress = tbNVAdress.Text;
            string salary = tbNVSalary.Text;
            if (name == "" || displayname == "" || phoneNumber == "" || adress == "" || salary == "")
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
            }
            else
            {
                queryData data = new queryData();
                string query = string.Format("insert into Account(userName,passWord,type) " +
                    "values(N'{0}',N'123456',0)", name);
                queryData data1 = new queryData();
                string query1 = string.Format("insert into AccountInfo(userName,displayName,address,Phone,Salary)" +
                    " values(N'{0}', N'{1}', N'{2}', N'{3}', {4})", name, displayname, adress, phoneNumber, salary);
                data.AddOrFixOrDelete(query);
                data1.AddOrFixOrDelete(query1);
                MessageBox.Show("Thêm nhân viên " + displayname + " thành công!");
            }
        }

        private void btStaffAddCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
