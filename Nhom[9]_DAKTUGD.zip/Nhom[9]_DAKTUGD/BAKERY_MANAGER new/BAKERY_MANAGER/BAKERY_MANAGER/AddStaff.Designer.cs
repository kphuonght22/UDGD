﻿namespace BAKERY_MANAGER
{
    partial class AddStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbNVName = new System.Windows.Forms.TextBox();
            this.tbNVDisplayName = new System.Windows.Forms.TextBox();
            this.tbNVNumberPhone = new System.Windows.Forms.TextBox();
            this.tbNVAdress = new System.Windows.Forms.TextBox();
            this.tbNVSalary = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btstaffAddOk = new System.Windows.Forms.Button();
            this.btStaffAddCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(57, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 44);
            this.label1.TabIndex = 17;
            this.label1.Text = "Thêm nhân viên";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbNVName
            // 
            this.tbNVName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNVName.Location = new System.Drawing.Point(123, 71);
            this.tbNVName.Name = "tbNVName";
            this.tbNVName.Size = new System.Drawing.Size(220, 22);
            this.tbNVName.TabIndex = 18;
            // 
            // tbNVDisplayName
            // 
            this.tbNVDisplayName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNVDisplayName.Location = new System.Drawing.Point(123, 129);
            this.tbNVDisplayName.Name = "tbNVDisplayName";
            this.tbNVDisplayName.Size = new System.Drawing.Size(220, 22);
            this.tbNVDisplayName.TabIndex = 19;
            // 
            // tbNVNumberPhone
            // 
            this.tbNVNumberPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNVNumberPhone.Location = new System.Drawing.Point(121, 192);
            this.tbNVNumberPhone.Name = "tbNVNumberPhone";
            this.tbNVNumberPhone.Size = new System.Drawing.Size(220, 22);
            this.tbNVNumberPhone.TabIndex = 21;
            // 
            // tbNVAdress
            // 
            this.tbNVAdress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNVAdress.Location = new System.Drawing.Point(121, 256);
            this.tbNVAdress.Name = "tbNVAdress";
            this.tbNVAdress.Size = new System.Drawing.Size(220, 22);
            this.tbNVAdress.TabIndex = 29;
            // 
            // tbNVSalary
            // 
            this.tbNVSalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNVSalary.Location = new System.Drawing.Point(121, 321);
            this.tbNVSalary.Name = "tbNVSalary";
            this.tbNVSalary.Size = new System.Drawing.Size(220, 22);
            this.tbNVSalary.TabIndex = 30;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 16);
            this.label6.TabIndex = 31;
            this.label6.Text = "Tên tài khoảng:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 132);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label7.Size = new System.Drawing.Size(109, 16);
            this.label7.TabIndex = 32;
            this.label7.Text = "Tên nhân viên:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 195);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 16);
            this.label9.TabIndex = 33;
            this.label9.Text = "Số điện thoại:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(12, 259);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 16);
            this.label10.TabIndex = 34;
            this.label10.Text = "Địa chỉ:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 324);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 16);
            this.label11.TabIndex = 35;
            this.label11.Text = "Lương:";
            // 
            // btstaffAddOk
            // 
            this.btstaffAddOk.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btstaffAddOk.Location = new System.Drawing.Point(233, 360);
            this.btstaffAddOk.Name = "btstaffAddOk";
            this.btstaffAddOk.Size = new System.Drawing.Size(101, 25);
            this.btstaffAddOk.TabIndex = 36;
            this.btstaffAddOk.Text = "Ok";
            this.btstaffAddOk.UseVisualStyleBackColor = true;
            this.btstaffAddOk.Click += new System.EventHandler(this.btstaffAddOk_Click);
            // 
            // btStaffAddCancel
            // 
            this.btStaffAddCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btStaffAddCancel.Location = new System.Drawing.Point(61, 360);
            this.btStaffAddCancel.Name = "btStaffAddCancel";
            this.btStaffAddCancel.Size = new System.Drawing.Size(96, 25);
            this.btStaffAddCancel.TabIndex = 37;
            this.btStaffAddCancel.Text = "Cancel";
            this.btStaffAddCancel.UseVisualStyleBackColor = true;
            this.btStaffAddCancel.Click += new System.EventHandler(this.btStaffAddCancel_Click);
            // 
            // AddStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(346, 393);
            this.Controls.Add(this.btStaffAddCancel);
            this.Controls.Add(this.btstaffAddOk);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbNVSalary);
            this.Controls.Add(this.tbNVAdress);
            this.Controls.Add(this.tbNVNumberPhone);
            this.Controls.Add(this.tbNVDisplayName);
            this.Controls.Add(this.tbNVName);
            this.Controls.Add(this.label1);
            this.Name = "AddStaff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddStaff";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbNVName;
        private System.Windows.Forms.TextBox tbNVDisplayName;
        private System.Windows.Forms.TextBox tbNVNumberPhone;
        private System.Windows.Forms.TextBox tbNVAdress;
        private System.Windows.Forms.TextBox tbNVSalary;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btstaffAddOk;
        private System.Windows.Forms.Button btStaffAddCancel;
    }
}