﻿using BAKERY_MANAGER.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BakeryManeger
{
    public partial class fLogin : Form
    {
        BAKERY_MANAGER.Models.BakeryManeger context = new BAKERY_MANAGER.Models.BakeryManeger();
        public fLogin()
        {
            InitializeComponent();
            cbxStaff.Checked = true;
        }
        public delegate void delPassData(TextBox text);
        void resetLogin()
        {
            tbxUserName.Text = "";
            tbxPassWord.Text = "";
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {

            Account db = context.Accounts.FirstOrDefault(p => p.userName == tbxUserName.Text);
            if (cbxStaff.Checked)
            {
                if (db != null && db.passWord == tbxPassWord.Text && db.type == false)
                {
                    MessageBox.Show("Đăng nhập thành công!!!");
                    fStaffManager f1 = new fStaffManager();
                    this.Hide();
                    delPassData del = new delPassData(f1.loadStaffName);
                    del(this.tbxUserName);
                    f1.ShowDialog();
                    resetLogin();
                    this.Show();
                }
                else
                {
                    MessageBox.Show("Sai tài khoản / mật khẩu!!!");
                }
            }
            if (cbxAdmin.Checked)
            {
                if (db != null && db.passWord == tbxPassWord.Text && db.type == true)
                {
                    MessageBox.Show("Đăng nhập thành công!!!");
                    BAKERY_MANAGER.fAdminManager f2 = new BAKERY_MANAGER.fAdminManager();
                    this.Hide();
                    f2.ShowDialog();
                    resetLogin();
                    this.Show();
                }
                else
                {
                    MessageBox.Show("Sai tài khoản / mật khẩu!!!");
                }
            }
            if (!cbxAdmin.Checked && !cbxStaff.Checked)
            {
                MessageBox.Show("Chọn đối tượng truy cập!");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn muốn thoát chương trình?", "Thông báo!!!", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void cbxStaff_CheckedChanged(object sender, EventArgs e)
        {
            cbxAdmin.Checked = false;
        }

        private void cbxAdmin_CheckedChanged(object sender, EventArgs e)
        {
            cbxStaff.Checked = false;
        }

    }
}
