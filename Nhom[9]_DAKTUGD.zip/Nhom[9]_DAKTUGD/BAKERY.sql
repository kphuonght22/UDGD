﻿CREATE DATABASE BAKERY

USE BAKERY

CREATE TABLE Account
(
	userName NVARCHAR(50) PRIMARY KEY NOT NULL,
	passWord NVARCHAR(100) NOT NULL,
	type BIT DEFAULT 0 NOT NULL,
)
GO

CREATE TABLE AccountInfo
(
	userName NVARCHAR(50) NOT NULL,
	displayName NVARCHAR(100) DEFAULT N'Chưa đặt tên' NOT NULL,
	address NVARCHAR(100),
	phone NVARCHAR(50),
	salary INT NOT NULL,

	FOREIGN KEY (userName) REFERENCES Account (userName)
)
GO

CREATE TABLE Customer
(
	id INT IDENTITY PRIMARY KEY,
	phone NVARCHAR(50) NOT NULL,
	name NVARCHAR(50) NOT NULL,
	point INT DEFAULT 0
)
GO

CREATE TABLE FoodCategory
(
	id INT IDENTITY PRIMARY KEY,
	name NVARCHAR(50) NOT NULL
)
GO

CREATE TABLE Food
(
	id INT IDENTITY PRIMARY KEY,
	name NVARCHAR(100) NOT NULL,
	idCategory INT NOT NULL,
	price INT NOT NULL,
	describe NVARCHAR(200),

	FOREIGN KEY (idCategory) REFERENCES FoodCategory(id)
)
GO

CREATE TABLE Bill
(
	id INT IDENTITY PRIMARY KEY,
	idCustomer INT NOT NULL DEFAULT 1,
	timePay DATETIME NOT NULL,
	moneyPay INT NOT NULL,

	FOREIGN KEY (idCustomer) REFERENCES Customer(id)
)
GO

CREATE TABLE BillInfo
(
	idBill INT NOT NULL,
	idFood INT NOT NULL,
	count INT NOT NULL,
	bPrice int NOT NULL,

	FOREIGN KEY (idBill) REFERENCES Bill(id),
	FOREIGN KEY (idFood) REFERENCES Food(id)
)
GO
INSERT INTO Account(userName,passWord,type)
VALUES(N'admin',N'123456',1)

INSERT INTO Customer(phone,name,point)
VALUES('123456789',N'NoName',0)

INSERT INTO FoodCategory(name)
VALUES(N'Bánh ngọt'),(N'Bánh mặn'),(N'Trà')

INSERT INTO Food(name,idCategory,price,describe)
VALUES(N'Tiramisu',1,39000,N'Không chất béo, bao ngon'),(N'Bông lan trứng muối',2,99000,N'Bánh 2 trứng ...'),
(N'Hồng trà',3,12000,N'Trà nguyên chất ngon nha')